# Social settlement and duplicate cleanup

Use this after every confirmation and before any possible repost or deletion.

## Settle one publish attempt

1. Run `ghostget runs show <run-id> --json` and append the result state to the task ledger.
2. Record any response-bound provider locator. Do not recover a target by text search, profile-feed position, or approximate time.
3. For `submitted`, use the publish contract's independently verified readback evidence. When it does not establish external availability and an observed `posts.read` accepts the exact returned locator, invoke that exact R1 schema and record the observation.
4. For `pending`, `partial`, or `indeterminate`, preserve all evidence. Run `ghostget runs reconcile <run-id> --json` only when the installed exact contract advertises reconciliation. Reconciliation is read-only, append-only, and never repeats the mutation.
5. Treat an absent or inconclusive read as unresolved, not as proof that the write never happened. Repeat only the bounded read/reconciliation when supported; never repeat the mutation.
6. For pre-dispatch `failed`, create a new preview only while the exact original action remains authorized.

If a current legacy reconciler explicitly requests original input, supply only the exact confirmed input that Ghostget verifies against the receipt. Never reconstruct or alter it to force a match.

## Keep an exact duplicate ledger

Maintain a private append-only event ledger with one attempt row containing:

- package identity and exact scalar-input hash;
- ordered attachment hashes and media types;
- platform, adapter, transport, auth-realm label, and bound subject;
- plan digest and expiry, run ID, and current run state;
- exact provider locator returned or retained after acceptance;
- readback kind and first observed time;
- `duplicate-risk-of` links to earlier attempt run IDs;
- any canonical delete plan/run and exact post-delete proof.

Do not put credentials, cookie values, response bodies, post text, or original local paths in the ledger. Never merge two attempts because their text looks alike. Record one provider object per exact locator, including an intentional duplicate.

## Create a fresh duplicate-tolerant intent

Only proceed when the user freshly authorizes the exact platform, exact package, and possibility that the unresolved source run already created the post. Append the source link to the private task ledger, then create a fresh preview:

```sh
ghostget invoke <adapter> posts.publish \
  --input @/absolute/private/post-input.json \
  --auth <bound-auth-id> \
  --duplicate-risk-of <indeterminate-run-id> \
  --preview --json
```

Version 1 accepts exactly one source run and only a one-dispatch R3 `posts.publish` operation on the `web-session-api` or the portable plugin transport. An official OAuth or other `provider-api` attempt is ineligible. Ghostget must prove that the source is an unclaimed, retained, terminal `indeterminate` run with the exact same adapter, auth realm, operation, risk, input, contract, receipt, journal, ledger, recovery capsule, and retained attachment bytes. The auth realm must keep the source's locator ID and kind; after a reconnect, the new auth record must name the provider subject that the source's recovery capsule recorded, and a source whose capsule recorded no subject needs its exact auth record. A historical attempt under another contract or adapter remains in the task ledger but is not a valid source. Review the warning and successor fingerprint in the new preview, then confirm its digest once; never put `--duplicate-risk-of` on `ghostget confirm`.

Ghostget permanently elects only one successor for the source and keeps successful successor idempotency evidence from expiring. If the source changes, reconciles, lacks exact retained evidence, already elected a successor, or fails any binding check, stop and report the refusal. Do not select a looser source, add a nonce, clear state, or bypass the check.

If a duplicate-intent child fails before successor election, its dispatch remains at zero and the source can remain eligible; re-check both runs, then re-preview that same source to derive the same successor intent. If the source was elected but a later local journal step failed, the lineage is intentionally stranded and must not be retried. If a child becomes `indeterminate` after dispatch and another possible duplicate is freshly authorized, cite that eligible child—not any ancestor—to extend one linear chain. Never branch or reuse an already claimed source.

This does not settle or replace an older run. Keep its Ghostget ledger and recovery material intact, and reconcile it separately when exact evidence becomes available. Once the elected successor settles after its dispatch, Ghostget marks the source `supersededBy` that successor: the source's recovery capsule and retained assets are released, so a portable source stops blocking its plugin bundle, but its indeterminate ledger stays and the intent fence still counts its possible effect.

## Delete a proven duplicate

Deletion is eligible only when all of these are true:

1. The exact provider locator is in the duplicate ledger.
2. An observed exact `posts.read` proves the object, current-account authorship, and content/media binding before deletion.
3. The same installed adapter exposes canonical `content.delete` as observed and executable. An absent or `capture-required` operation, or an R4 runtime block, means deletion is unavailable.
4. Its schema accepts that exact locator; the preview binds the account, target, side effect, and contract; and the user confirms that digest once.
5. A separate exact post-delete R1 contract proves a target-bound tombstone or exact not-found result whose reviewed semantics establish deletion. General feed absence is not proof.

If deletion becomes `pending`, `partial`, or `indeterminate`, preserve it and reconcile only through its advertised exact readback. Never retry deletion. Never substitute `posts.delete`, another semantic name, direct browser interaction, raw HTTP, or capture replay for `content.delete`.

For the observed Bluesky contract, carry the exact authored `post_uri` and the
authoritative current `expected_cid` into the preview. CID drift is a refusal,
not permission to delete a newer revision. A successful mutation is settled
only by authoritative PDS `RecordNotFound`; AppView/feed absence alone is not
proof. Never use this cleanup path for an intended post merely because another
platform attempt is uncertain.

## Report availability time precisely

Keep these times distinct:

- plan creation/confirmation: local authorization, not publication;
- dispatch start/finish: Ghostget transport timing, not external availability;
- provider-created time: a provider-authored value, when strictly bound;
- first observed time: when exact independent readback saw the object.

Report first observation as “available no later than” that time; the actual visibility onset may have been earlier. When readback remains unresolved, say “provider accepted” only when proven and “external availability unverified.”
