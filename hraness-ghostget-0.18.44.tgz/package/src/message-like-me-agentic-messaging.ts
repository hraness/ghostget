import { types as nodeTypes } from "node:util";

import { canonicalJson, sha256 } from "./canonical-json";

// Historical wire names and digest inputs are intentionally unchanged: existing
// Message Like Me bindings and encrypted receipts survive the Ghostget rename.
export const MESSAGE_LIKE_ME_SOURCE_CONVERSATION_COORDINATE_V1_SCHEMA_VERSION = 1 as const;
export const MESSAGE_LIKE_ME_SOURCE_CONVERSATION_COORDINATE_V1_CONTRACT_ID =
  "wrench.message-like-me.source-conversation-coordinate.v1" as const;

/** Exact read-only predecessor shipped by Ghostget #72. */
export const GHOSTGET_MESSAGING_CONTEXT_BINDING_V1_FORMAT =
  "wrench.messaging-context-binding" as const;
export const GHOSTGET_MESSAGING_CONTEXT_BINDING_V1_CONTRACT_ID =
  "wrench.messaging-context-binding.v1" as const;
export const GHOSTGET_MESSAGING_CONTEXT_BINDING_V1_CONTRACT_DESCRIPTOR = Object.freeze({
  contractId: GHOSTGET_MESSAGING_CONTEXT_BINDING_V1_CONTRACT_ID,
  fields: Object.freeze([
    "schemaVersion:1",
    "format:wrench.messaging-context-binding",
    "contractId:wrench.messaging-context-binding.v1",
    "contractHash:sha256",
    "routeRef:opaque",
    "contextRef:opaque",
    "exactDataRevision:sha256",
    "latestMessageRevision:sha256",
    "validatedAt:rfc3339",
    "expiresAt:rfc3339",
  ]),
  format: "wrench.messaging-contract-descriptor" as const,
  schemaVersion: 1 as const,
});
export const GHOSTGET_MESSAGING_CONTEXT_BINDING_V1_CONTRACT_HASH =
  "5e64da6a3d826e7f6fa3db7dca0a4ba92c10cfb784981e71a25aed9513a5c687" as const;

/** Exact terminal-receipt predecessor shipped by Ghostget #72. */
export const GHOSTGET_MESSAGING_RECEIPT_BINDING_V1_FORMAT =
  "wrench.messaging-receipt-binding" as const;
export const GHOSTGET_MESSAGING_RECEIPT_BINDING_V1_CONTRACT_ID =
  "wrench.messaging-receipt-binding.v1" as const;
export const GHOSTGET_MESSAGING_RECEIPT_BINDING_V1_CONTRACT_DESCRIPTOR = Object.freeze({
  contractId: GHOSTGET_MESSAGING_RECEIPT_BINDING_V1_CONTRACT_ID,
  fields: Object.freeze([
    "schemaVersion:1",
    "format:wrench.messaging-receipt-binding",
    "contractId:wrench.messaging-receipt-binding.v1",
    "contractHash:sha256",
    "clientIntentSha256:sha256",
    "routeRefSha256:sha256",
    "contextRefSha256:sha256",
    "turnDigest:sha256",
    "previewDigest:sha256",
    "runId:opaque",
    "state:submitted|failed|partial|indeterminate",
    "partCount:uint",
    "provenPartCount:uint",
    "receiptSha256:sha256",
    "recordedAt:rfc3339",
  ]),
  format: "wrench.messaging-contract-descriptor" as const,
  schemaVersion: 1 as const,
});
export const GHOSTGET_MESSAGING_RECEIPT_BINDING_V1_CONTRACT_HASH =
  "7f6cf724f0200b2399e4f4641c637b20b48914fc5c9b13755127a8ec69fe66f4" as const;

export const GHOSTGET_MESSAGING_CONTEXT_BINDING_V2_FORMAT =
  "wrench.messaging-context-binding" as const;
export const GHOSTGET_MESSAGING_CONTEXT_BINDING_V2_CONTRACT_ID =
  "wrench.messaging-context-binding.v2" as const;
export const GHOSTGET_MESSAGING_CONTEXT_BINDING_V2_CONTRACT_DESCRIPTOR = Object.freeze({
  contractId: GHOSTGET_MESSAGING_CONTEXT_BINDING_V2_CONTRACT_ID,
  fields: Object.freeze([
    "schemaVersion:2",
    "format:wrench.messaging-context-binding",
    "contractId:wrench.messaging-context-binding.v2",
    "contractHash:sha256",
    "sourceConversationCoordinate:{contractId,schemaVersion,sha256}",
    "routeRef:opaque",
    "contextRef:opaque",
    "exactDataRevision:sha256",
    "latestMessageRevision:sha256",
    "validatedAt:rfc3339",
    "expiresAt:rfc3339",
  ]),
  format: "wrench.messaging-contract-descriptor" as const,
  schemaVersion: 2 as const,
});
export const GHOSTGET_MESSAGING_CONTEXT_BINDING_V2_CONTRACT_HASH = sha256(
  canonicalJson(GHOSTGET_MESSAGING_CONTEXT_BINDING_V2_CONTRACT_DESCRIPTOR),
);

export const GHOSTGET_MESSAGING_RECEIPT_BINDING_V2_FORMAT =
  "wrench.messaging-receipt-binding" as const;
export const GHOSTGET_MESSAGING_RECEIPT_BINDING_V2_CONTRACT_ID =
  "wrench.messaging-receipt-binding.v2" as const;
export const GHOSTGET_MESSAGING_RECEIPT_BINDING_V2_CONTRACT_DESCRIPTOR = Object.freeze({
  contractId: GHOSTGET_MESSAGING_RECEIPT_BINDING_V2_CONTRACT_ID,
  fields: Object.freeze([
    "schemaVersion:2",
    "format:wrench.messaging-receipt-binding",
    "contractId:wrench.messaging-receipt-binding.v2",
    "contractHash:sha256",
    "clientIntentSha256:sha256",
    "contextBindingSha256:sha256",
    "sourceConversationCoordinateSha256:sha256",
    "routeRefSha256:sha256",
    "contextRefSha256:sha256",
    "turnDigest:sha256",
    "previewDigest:sha256",
    "runId:opaque",
    "state:submitted|failed|partial|indeterminate",
    "partCount:uint",
    "provenPartCount:uint",
    "receiptSha256:sha256",
    "recordedAt:rfc3339",
  ]),
  format: "wrench.messaging-contract-descriptor" as const,
  schemaVersion: 2 as const,
});
export const GHOSTGET_MESSAGING_RECEIPT_BINDING_V2_CONTRACT_HASH = sha256(
  canonicalJson(GHOSTGET_MESSAGING_RECEIPT_BINDING_V2_CONTRACT_DESCRIPTOR),
);

export const GHOSTGET_MESSAGING_CLIENT_INTENT_BINDING_V1_FORMAT =
  "wrench.messaging-client-intent-binding" as const;
export const GHOSTGET_MESSAGING_CLIENT_INTENT_BINDING_V1_CONTRACT_ID =
  "wrench.messaging-client-intent-binding.v1" as const;
export const GHOSTGET_MESSAGING_CONTEXT_INSTANCE_V1_CONTRACT_ID =
  "wrench.messaging-context-instance.v1" as const;
export const GHOSTGET_MESSAGING_CONTEXT_INSTANCE_V2_CONTRACT_ID =
  "wrench.messaging-context-instance.v2" as const;

export type MessageLikeMeSourceConversationCoordinateV1 = Readonly<{
  sourceAccountId: string | null;
  sourceExternalId: string;
  coordinate:
    | Readonly<{
      kind: "beeperConversation";
      network: string;
      conversationId: string;
    }>
    | Readonly<{
      kind: "imessageChat";
      chatGuid: string;
      service: string | null;
      observedChatRowId: number | null;
    }>;
}>;

export type MessageLikeMeSourceConversationCoordinateBindingV1 = Readonly<{
  contractId: typeof MESSAGE_LIKE_ME_SOURCE_CONVERSATION_COORDINATE_V1_CONTRACT_ID;
  schemaVersion: typeof MESSAGE_LIKE_ME_SOURCE_CONVERSATION_COORDINATE_V1_SCHEMA_VERSION;
  sha256: string;
}>;

export type GhostgetMessagingContextBindingV1 = Readonly<{
  schemaVersion: 1;
  format: typeof GHOSTGET_MESSAGING_CONTEXT_BINDING_V1_FORMAT;
  contractId: typeof GHOSTGET_MESSAGING_CONTEXT_BINDING_V1_CONTRACT_ID;
  contractHash: typeof GHOSTGET_MESSAGING_CONTEXT_BINDING_V1_CONTRACT_HASH;
  routeRef: string;
  contextRef: string;
  exactDataRevision: string;
  latestMessageRevision: string;
  validatedAt: string;
  expiresAt: string;
}>;

export type GhostgetMessagingContextBindingV2 = Readonly<{
  schemaVersion: 2;
  format: typeof GHOSTGET_MESSAGING_CONTEXT_BINDING_V2_FORMAT;
  contractId: typeof GHOSTGET_MESSAGING_CONTEXT_BINDING_V2_CONTRACT_ID;
  contractHash: string;
  sourceConversationCoordinate: MessageLikeMeSourceConversationCoordinateBindingV1;
  routeRef: string;
  contextRef: string;
  exactDataRevision: string;
  latestMessageRevision: string;
  validatedAt: string;
  expiresAt: string;
}>;

export type GhostgetMessagingReceiptStateV2 =
  | "failed"
  | "indeterminate"
  | "partial"
  | "submitted";

export type GhostgetMessagingReceiptStateV1 = GhostgetMessagingReceiptStateV2;

export type GhostgetMessagingClientIntentBindingV1 = Readonly<{
  schemaVersion: 1;
  format: typeof GHOSTGET_MESSAGING_CLIENT_INTENT_BINDING_V1_FORMAT;
  contractId: typeof GHOSTGET_MESSAGING_CLIENT_INTENT_BINDING_V1_CONTRACT_ID;
  clientIntentSha256: string;
  contextBindingSha256: string;
  sourceConversationCoordinateSha256: string;
  routeRefSha256: string;
  contextRefSha256: string;
  turnDigest: string;
  partCount: number;
}>;

export type GhostgetMessagingReceiptBindingV2 = Readonly<{
  schemaVersion: 2;
  format: typeof GHOSTGET_MESSAGING_RECEIPT_BINDING_V2_FORMAT;
  contractId: typeof GHOSTGET_MESSAGING_RECEIPT_BINDING_V2_CONTRACT_ID;
  contractHash: string;
  clientIntentSha256: string;
  contextBindingSha256: string;
  sourceConversationCoordinateSha256: string;
  routeRefSha256: string;
  contextRefSha256: string;
  turnDigest: string;
  previewDigest: string;
  runId: string;
  state: GhostgetMessagingReceiptStateV2;
  partCount: number;
  provenPartCount: number;
  receiptSha256: string;
  recordedAt: string;
}>;

export type GhostgetMessagingReceiptBindingV1 = Readonly<{
  schemaVersion: 1;
  format: typeof GHOSTGET_MESSAGING_RECEIPT_BINDING_V1_FORMAT;
  contractId: typeof GHOSTGET_MESSAGING_RECEIPT_BINDING_V1_CONTRACT_ID;
  contractHash: typeof GHOSTGET_MESSAGING_RECEIPT_BINDING_V1_CONTRACT_HASH;
  clientIntentSha256: string;
  routeRefSha256: string;
  contextRefSha256: string;
  turnDigest: string;
  previewDigest: string;
  runId: string;
  state: GhostgetMessagingReceiptStateV1;
  partCount: number;
  provenPartCount: number;
  receiptSha256: string;
  recordedAt: string;
}>;

type PlainObject = Record<string, unknown>;

function fail(message: string): never {
  throw new TypeError(message);
}

function plainObject(value: unknown, label: string): PlainObject {
  if (
    value === null
    || typeof value !== "object"
    || Array.isArray(value)
    || nodeTypes.isProxy(value)
    || (Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null)
  ) return fail(`${label} must be a plain object`);
  for (const key of Reflect.ownKeys(value)) {
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (
      typeof key !== "string"
      || descriptor === undefined
      || !("value" in descriptor)
      || !descriptor.enumerable
    ) return fail(`${label} must contain only enumerable string-keyed data properties`);
  }
  return value as PlainObject;
}

function exactKeys(value: PlainObject, expected: readonly string[], label: string): void {
  const actual = Object.keys(value).sort();
  const sortedExpected = [...expected].sort();
  if (
    actual.length !== sortedExpected.length
    || actual.some((key, index) => key !== sortedExpected[index])
  ) return fail(`${label} must contain exactly ${sortedExpected.join(", ")}`);
}

function isWellFormedUnicode(value: string): boolean {
  for (let index = 0; index < value.length; index += 1) {
    const unit = value.charCodeAt(index);
    if (unit >= 0xd800 && unit <= 0xdbff) {
      const next = value.charCodeAt(index + 1);
      if (!(next >= 0xdc00 && next <= 0xdfff)) return false;
      index += 1;
    } else if (unit >= 0xdc00 && unit <= 0xdfff) {
      return false;
    }
  }
  return true;
}

function text(value: unknown, label: string, maximumBytes = 1_024): string {
  if (
    typeof value !== "string"
    || value.length === 0
    || Buffer.byteLength(value, "utf8") > maximumBytes
    || /\p{Cc}|\p{Zl}|\p{Zp}/u.test(value)
    || value !== value.trim()
    || !isWellFormedUnicode(value)
  ) return fail(`${label} must be bounded well-formed text without controls or surrounding space`);
  return value;
}

function digest(value: unknown, label: string): string {
  if (typeof value !== "string" || !/^[a-f0-9]{64}$/u.test(value)) {
    return fail(`${label} must be a lowercase SHA-256 digest`);
  }
  return value;
}

function timestamp(value: unknown, label: string): string {
  if (
    typeof value !== "string"
    || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/u.test(value)
    || new Date(value).toISOString() !== value
  ) return fail(`${label} must be a canonical RFC 3339 timestamp`);
  return value;
}

function legacyTimestamp(value: unknown, label: string): string {
  if (
    typeof value !== "string"
    || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?Z$/u.test(value)
    || !Number.isFinite(Date.parse(value))
  ) return fail(`${label} must be an RFC 3339 UTC timestamp`);
  return value;
}

export function parseMessageLikeMeSourceConversationCoordinateV1(
  value: unknown,
): MessageLikeMeSourceConversationCoordinateV1 {
  const source = plainObject(value, "Message Like Me source-conversation coordinate");
  exactKeys(
    source,
    ["sourceAccountId", "sourceExternalId", "coordinate"],
    "Message Like Me source-conversation coordinate",
  );
  const sourceExternalId = text(
    source.sourceExternalId,
    "Message Like Me source-conversation coordinate.sourceExternalId",
  );
  const coordinate = plainObject(
    source.coordinate,
    "Message Like Me source-conversation coordinate.coordinate",
  );
  if (coordinate.kind === "beeperConversation") {
    exactKeys(
      coordinate,
      ["kind", "network", "conversationId"],
      "Message Like Me Beeper coordinate",
    );
    const sourceAccountId = text(
      source.sourceAccountId,
      "Message Like Me source-conversation coordinate.sourceAccountId",
    );
    if (sourceExternalId !== sourceAccountId) {
      return fail("Message Like Me Beeper source account and external identity must match");
    }
    return Object.freeze({
      sourceAccountId,
      sourceExternalId,
      coordinate: Object.freeze({
        kind: "beeperConversation" as const,
        network: text(coordinate.network, "Message Like Me Beeper coordinate.network", 512),
        conversationId: text(
          coordinate.conversationId,
          "Message Like Me Beeper coordinate.conversationId",
        ),
      }),
    });
  }
  if (coordinate.kind === "imessageChat") {
    exactKeys(
      coordinate,
      ["kind", "chatGuid", "service", "observedChatRowId"],
      "Message Like Me iMessage coordinate",
    );
    if (source.sourceAccountId !== null) {
      return fail("Message Like Me iMessage sourceAccountId must be null");
    }
    let observedChatRowId: number | null;
    if (coordinate.observedChatRowId === null) {
      observedChatRowId = null;
    } else if (
      typeof coordinate.observedChatRowId === "number"
      && Number.isFinite(coordinate.observedChatRowId)
      && Number.isSafeInteger(coordinate.observedChatRowId)
      && coordinate.observedChatRowId >= 1
    ) {
      observedChatRowId = coordinate.observedChatRowId;
    } else {
      return fail("Message Like Me iMessage observedChatRowId must be a positive safe integer or null");
    }
    return Object.freeze({
      sourceAccountId: null,
      sourceExternalId,
      coordinate: Object.freeze({
        kind: "imessageChat" as const,
        chatGuid: text(coordinate.chatGuid, "Message Like Me iMessage coordinate.chatGuid"),
        service: coordinate.service === null
          ? null
          : text(coordinate.service, "Message Like Me iMessage coordinate.service", 512),
        observedChatRowId,
      }),
    });
  }
  return fail("Message Like Me source-conversation coordinate has an unsupported tag");
}

export function messageLikeMeSourceConversationCoordinateBindingV1(
  value: unknown,
): MessageLikeMeSourceConversationCoordinateBindingV1 {
  const coordinate = parseMessageLikeMeSourceConversationCoordinateV1(value);
  const canonicalPreimage = Object.freeze({
    contractId: MESSAGE_LIKE_ME_SOURCE_CONVERSATION_COORDINATE_V1_CONTRACT_ID,
    schemaVersion: MESSAGE_LIKE_ME_SOURCE_CONVERSATION_COORDINATE_V1_SCHEMA_VERSION,
    value: coordinate,
  });
  return Object.freeze({
    contractId: MESSAGE_LIKE_ME_SOURCE_CONVERSATION_COORDINATE_V1_CONTRACT_ID,
    schemaVersion: MESSAGE_LIKE_ME_SOURCE_CONVERSATION_COORDINATE_V1_SCHEMA_VERSION,
    sha256: sha256(canonicalJson(canonicalPreimage)),
  });
}

export function parseMessageLikeMeSourceConversationCoordinateBindingV1(
  value: unknown,
): MessageLikeMeSourceConversationCoordinateBindingV1 {
  const binding = plainObject(value, "Ghostget source-conversation coordinate binding");
  exactKeys(
    binding,
    ["contractId", "schemaVersion", "sha256"],
    "Ghostget source-conversation coordinate binding",
  );
  if (
    binding.contractId !== MESSAGE_LIKE_ME_SOURCE_CONVERSATION_COORDINATE_V1_CONTRACT_ID
    || binding.schemaVersion !== MESSAGE_LIKE_ME_SOURCE_CONVERSATION_COORDINATE_V1_SCHEMA_VERSION
  ) return fail("Ghostget source-conversation coordinate binding has an unsupported contract identity");
  return Object.freeze({
    contractId: MESSAGE_LIKE_ME_SOURCE_CONVERSATION_COORDINATE_V1_CONTRACT_ID,
    schemaVersion: MESSAGE_LIKE_ME_SOURCE_CONVERSATION_COORDINATE_V1_SCHEMA_VERSION,
    sha256: digest(binding.sha256, "Ghostget source-conversation coordinate binding.sha256"),
  });
}

export function parseGhostgetMessagingContextBindingV1(
  value: unknown,
): GhostgetMessagingContextBindingV1 {
  const context = plainObject(value, "Ghostget messaging context binding V1");
  exactKeys(context, [
    "schemaVersion",
    "format",
    "contractId",
    "contractHash",
    "routeRef",
    "contextRef",
    "exactDataRevision",
    "latestMessageRevision",
    "validatedAt",
    "expiresAt",
  ], "Ghostget messaging context binding V1");
  if (
    context.schemaVersion !== 1
    || context.format !== GHOSTGET_MESSAGING_CONTEXT_BINDING_V1_FORMAT
    || context.contractId !== GHOSTGET_MESSAGING_CONTEXT_BINDING_V1_CONTRACT_ID
    || context.contractHash !== GHOSTGET_MESSAGING_CONTEXT_BINDING_V1_CONTRACT_HASH
  ) return fail("Ghostget messaging context binding V1 has an unsupported contract identity");
  const validatedAt = legacyTimestamp(
    context.validatedAt,
    "Ghostget messaging context binding V1.validatedAt",
  );
  const expiresAt = legacyTimestamp(
    context.expiresAt,
    "Ghostget messaging context binding V1.expiresAt",
  );
  if (Date.parse(expiresAt) <= Date.parse(validatedAt)) {
    return fail("Ghostget messaging context binding V1.expiresAt must follow validatedAt");
  }
  return Object.freeze({
    schemaVersion: 1 as const,
    format: GHOSTGET_MESSAGING_CONTEXT_BINDING_V1_FORMAT,
    contractId: GHOSTGET_MESSAGING_CONTEXT_BINDING_V1_CONTRACT_ID,
    contractHash: GHOSTGET_MESSAGING_CONTEXT_BINDING_V1_CONTRACT_HASH,
    routeRef: text(context.routeRef, "Ghostget messaging context binding V1.routeRef", 2_048),
    contextRef: text(context.contextRef, "Ghostget messaging context binding V1.contextRef", 2_048),
    exactDataRevision: digest(
      context.exactDataRevision,
      "Ghostget messaging context binding V1.exactDataRevision",
    ),
    latestMessageRevision: digest(
      context.latestMessageRevision,
      "Ghostget messaging context binding V1.latestMessageRevision",
    ),
    validatedAt,
    expiresAt,
  });
}

export function parseGhostgetMessagingContextBindingV2(
  value: unknown,
): GhostgetMessagingContextBindingV2 {
  const context = plainObject(value, "Ghostget messaging context binding");
  exactKeys(context, [
    "schemaVersion",
    "format",
    "contractId",
    "contractHash",
    "sourceConversationCoordinate",
    "routeRef",
    "contextRef",
    "exactDataRevision",
    "latestMessageRevision",
    "validatedAt",
    "expiresAt",
  ], "Ghostget messaging context binding");
  if (
    context.schemaVersion !== 2
    || context.format !== GHOSTGET_MESSAGING_CONTEXT_BINDING_V2_FORMAT
    || context.contractId !== GHOSTGET_MESSAGING_CONTEXT_BINDING_V2_CONTRACT_ID
    || context.contractHash !== GHOSTGET_MESSAGING_CONTEXT_BINDING_V2_CONTRACT_HASH
  ) return fail("Ghostget messaging context binding has an unsupported contract identity");
  const validatedAt = timestamp(context.validatedAt, "Ghostget messaging context binding.validatedAt");
  const expiresAt = timestamp(context.expiresAt, "Ghostget messaging context binding.expiresAt");
  const lifetime = Date.parse(expiresAt) - Date.parse(validatedAt);
  if (lifetime <= 0 || lifetime > 24 * 60 * 60 * 1_000) {
    return fail("Ghostget messaging context binding has an invalid lifetime");
  }
  return Object.freeze({
    schemaVersion: 2 as const,
    format: GHOSTGET_MESSAGING_CONTEXT_BINDING_V2_FORMAT,
    contractId: GHOSTGET_MESSAGING_CONTEXT_BINDING_V2_CONTRACT_ID,
    contractHash: GHOSTGET_MESSAGING_CONTEXT_BINDING_V2_CONTRACT_HASH,
    sourceConversationCoordinate: parseMessageLikeMeSourceConversationCoordinateBindingV1(
      context.sourceConversationCoordinate,
    ),
    routeRef: text(context.routeRef, "Ghostget messaging context binding.routeRef", 2_048),
    contextRef: text(context.contextRef, "Ghostget messaging context binding.contextRef", 2_048),
    exactDataRevision: digest(
      context.exactDataRevision,
      "Ghostget messaging context binding.exactDataRevision",
    ),
    latestMessageRevision: digest(
      context.latestMessageRevision,
      "Ghostget messaging context binding.latestMessageRevision",
    ),
    validatedAt,
    expiresAt,
  });
}

export function ghostgetMessagingContextBindingSha256V1(value: unknown): string {
  const context = parseGhostgetMessagingContextBindingV1(value);
  return sha256(canonicalJson({
    contractId: GHOSTGET_MESSAGING_CONTEXT_INSTANCE_V1_CONTRACT_ID,
    schemaVersion: 1,
    value: context,
  }));
}

function parsedContextBindingSha256V2(context: GhostgetMessagingContextBindingV2): string {
  return sha256(canonicalJson({
    contractId: GHOSTGET_MESSAGING_CONTEXT_INSTANCE_V2_CONTRACT_ID,
    schemaVersion: 2,
    value: context,
  }));
}

export function ghostgetMessagingContextBindingSha256V2(value: unknown): string {
  return parsedContextBindingSha256V2(parseGhostgetMessagingContextBindingV2(value));
}

const BEEPER_EXACT_CONVERSATION_KEYS = Object.freeze([
  "id",
  "localChatId",
  "accountId",
  "network",
  "title",
  "type",
  "description",
  "descriptionObserved",
  "hasAvatar",
  "avatarObserved",
  "lastReadMessageSortKey",
  "lastActivity",
  "unreadCount",
  "unreadMentionsCount",
  "isMarkedUnread",
  "isArchived",
  "isLowPriority",
  "isMuted",
  "isPinned",
  "isReadOnly",
  "messageExpirySeconds",
  "messageExpiryObserved",
  "draft",
  "draftObserved",
  "reminder",
  "reminderObserved",
  "participants",
]);

export function createBeeperMessageLikeMeSourceConversationCoordinateBindingV1(
  input: Readonly<{
    conversationRead: unknown;
    expectedAccountSubject: unknown;
  }>,
): MessageLikeMeSourceConversationCoordinateBindingV1 {
  const read = plainObject(input.conversationRead, "Ghostget Beeper exact conversation read");
  exactKeys(
    read,
    ["provider", "operation", "accountSubject", "conversation"],
    "Ghostget Beeper exact conversation read",
  );
  if (read.provider !== "beeper" || read.operation !== "conversations.read") {
    return fail("Ghostget context requires an exact Beeper conversations.read projection");
  }
  const expectedAccountSubject = text(
    input.expectedAccountSubject,
    "Ghostget Beeper expected account subject",
  );
  if (
    text(read.accountSubject, "Ghostget Beeper exact conversation read.accountSubject")
    !== expectedAccountSubject
  ) return fail("Ghostget Beeper exact conversation read did not bind the expected account subject");
  const conversation = plainObject(
    read.conversation,
    "Ghostget Beeper exact conversation read.conversation",
  );
  exactKeys(
    conversation,
    BEEPER_EXACT_CONVERSATION_KEYS,
    "Ghostget Beeper exact conversation read.conversation",
  );
  if (conversation.type !== "single") {
    return fail("Ghostget Message Like Me context requires a direct Beeper conversation");
  }
  if (conversation.isReadOnly !== false) {
    return fail("Ghostget Message Like Me context requires a writable Beeper conversation");
  }
  const accountId = text(
    conversation.accountId,
    "Ghostget Beeper exact conversation read.conversation.accountId",
  );
  return messageLikeMeSourceConversationCoordinateBindingV1({
    sourceAccountId: accountId,
    sourceExternalId: accountId,
    coordinate: {
      kind: "beeperConversation",
      network: text(
        conversation.network,
        "Ghostget Beeper exact conversation read.conversation.network",
        512,
      ),
      conversationId: text(
        conversation.id,
        "Ghostget Beeper exact conversation read.conversation.id",
      ),
    },
  });
}

/**
 * Compatibility writer for the exact #72 context shape. New checked actions
 * must use V2 so the source-conversation coordinate is retained durably.
 */
export function createBeeperMessageLikeMeContextBindingV1(input: Readonly<{
  conversationRead: unknown;
  expectedAccountSubject: unknown;
  routeRef: unknown;
  contextRef: unknown;
  exactDataRevision: unknown;
  latestMessageRevision: unknown;
  validatedAt: unknown;
  expiresAt: unknown;
}>): GhostgetMessagingContextBindingV1 {
  createBeeperMessageLikeMeSourceConversationCoordinateBindingV1({
    conversationRead: input.conversationRead,
    expectedAccountSubject: input.expectedAccountSubject,
  });
  return parseGhostgetMessagingContextBindingV1(Object.freeze({
    schemaVersion: 1 as const,
    format: GHOSTGET_MESSAGING_CONTEXT_BINDING_V1_FORMAT,
    contractId: GHOSTGET_MESSAGING_CONTEXT_BINDING_V1_CONTRACT_ID,
    contractHash: GHOSTGET_MESSAGING_CONTEXT_BINDING_V1_CONTRACT_HASH,
    routeRef: text(input.routeRef, "Ghostget messaging context binding V1.routeRef", 2_048),
    contextRef: text(input.contextRef, "Ghostget messaging context binding V1.contextRef", 2_048),
    exactDataRevision: digest(
      input.exactDataRevision,
      "Ghostget messaging context binding V1.exactDataRevision",
    ),
    latestMessageRevision: digest(
      input.latestMessageRevision,
      "Ghostget messaging context binding V1.latestMessageRevision",
    ),
    validatedAt: input.validatedAt,
    expiresAt: input.expiresAt,
  }));
}

export function createBeeperMessageLikeMeContextBindingV2(input: Readonly<{
  conversationRead: unknown;
  expectedAccountSubject: unknown;
  routeRef: unknown;
  contextRef: unknown;
  exactDataRevision: unknown;
  latestMessageRevision: unknown;
  validatedAt: unknown;
  expiresAt: unknown;
}>): GhostgetMessagingContextBindingV2 {
  const sourceConversationCoordinate =
    createBeeperMessageLikeMeSourceConversationCoordinateBindingV1({
      conversationRead: input.conversationRead,
      expectedAccountSubject: input.expectedAccountSubject,
    });
  return parseGhostgetMessagingContextBindingV2(Object.freeze({
    schemaVersion: 2 as const,
    format: GHOSTGET_MESSAGING_CONTEXT_BINDING_V2_FORMAT,
    contractId: GHOSTGET_MESSAGING_CONTEXT_BINDING_V2_CONTRACT_ID,
    contractHash: GHOSTGET_MESSAGING_CONTEXT_BINDING_V2_CONTRACT_HASH,
    sourceConversationCoordinate,
    routeRef: text(input.routeRef, "Ghostget messaging context binding.routeRef", 2_048),
    contextRef: text(input.contextRef, "Ghostget messaging context binding.contextRef", 2_048),
    exactDataRevision: digest(
      input.exactDataRevision,
      "Ghostget messaging context binding.exactDataRevision",
    ),
    latestMessageRevision: digest(
      input.latestMessageRevision,
      "Ghostget messaging context binding.latestMessageRevision",
    ),
    validatedAt: input.validatedAt,
    expiresAt: input.expiresAt,
  }));
}

export function parseGhostgetMessagingClientIntentBindingV1(
  value: unknown,
  contextValue: unknown,
): GhostgetMessagingClientIntentBindingV1 {
  const context = parseGhostgetMessagingContextBindingV2(contextValue);
  const intent = plainObject(value, "Ghostget messaging client-intent binding");
  exactKeys(intent, [
    "schemaVersion",
    "format",
    "contractId",
    "clientIntentSha256",
    "contextBindingSha256",
    "sourceConversationCoordinateSha256",
    "routeRefSha256",
    "contextRefSha256",
    "turnDigest",
    "partCount",
  ], "Ghostget messaging client-intent binding");
  if (
    intent.schemaVersion !== 1
    || intent.format !== GHOSTGET_MESSAGING_CLIENT_INTENT_BINDING_V1_FORMAT
    || intent.contractId !== GHOSTGET_MESSAGING_CLIENT_INTENT_BINDING_V1_CONTRACT_ID
  ) return fail("Ghostget messaging client-intent binding has an unsupported contract identity");
  if (!Number.isSafeInteger(intent.partCount) || (intent.partCount as number) < 1 || (intent.partCount as number) > 8) {
    return fail("Ghostget messaging client-intent binding.partCount must be from 1 through 8");
  }
  const parsed = Object.freeze({
    schemaVersion: 1 as const,
    format: GHOSTGET_MESSAGING_CLIENT_INTENT_BINDING_V1_FORMAT,
    contractId: GHOSTGET_MESSAGING_CLIENT_INTENT_BINDING_V1_CONTRACT_ID,
    clientIntentSha256: digest(
      intent.clientIntentSha256,
      "Ghostget messaging client-intent binding.clientIntentSha256",
    ),
    contextBindingSha256: digest(
      intent.contextBindingSha256,
      "Ghostget messaging client-intent binding.contextBindingSha256",
    ),
    sourceConversationCoordinateSha256: digest(
      intent.sourceConversationCoordinateSha256,
      "Ghostget messaging client-intent binding.sourceConversationCoordinateSha256",
    ),
    routeRefSha256: digest(
      intent.routeRefSha256,
      "Ghostget messaging client-intent binding.routeRefSha256",
    ),
    contextRefSha256: digest(
      intent.contextRefSha256,
      "Ghostget messaging client-intent binding.contextRefSha256",
    ),
    turnDigest: digest(intent.turnDigest, "Ghostget messaging client-intent binding.turnDigest"),
    partCount: intent.partCount as number,
  });
  if (
    parsed.contextBindingSha256 !== parsedContextBindingSha256V2(context)
    || parsed.sourceConversationCoordinateSha256
      !== context.sourceConversationCoordinate.sha256
    || parsed.routeRefSha256 !== sha256(context.routeRef)
    || parsed.contextRefSha256 !== sha256(context.contextRef)
  ) return fail("Ghostget messaging client intent does not bind the exact context instance");
  return parsed;
}

export function createGhostgetMessagingReceiptBindingV2(input: Readonly<{
  context: unknown;
  clientIntent: unknown;
  previewDigest: unknown;
  runId: unknown;
  state: unknown;
  provenPartCount: unknown;
  recordedAt: unknown;
}>): GhostgetMessagingReceiptBindingV2 {
  const intent = parseGhostgetMessagingClientIntentBindingV1(input.clientIntent, input.context);
  if (
    input.state !== "submitted"
    && input.state !== "failed"
    && input.state !== "partial"
    && input.state !== "indeterminate"
  ) return fail("Ghostget messaging receipt binding has an invalid state");
  if (
    !Number.isSafeInteger(input.provenPartCount)
    || (input.provenPartCount as number) < 0
    || (input.provenPartCount as number) > intent.partCount
  ) return fail("Ghostget messaging receipt binding.provenPartCount is out of range");
  const provenPartCount = input.provenPartCount as number;
  if (
    (input.state === "submitted" && provenPartCount !== intent.partCount)
    || (input.state === "failed" && provenPartCount !== 0)
    || (input.state === "partial"
      && (provenPartCount < 1 || provenPartCount >= intent.partCount))
    || (input.state === "indeterminate" && provenPartCount >= intent.partCount)
  ) return fail("Ghostget messaging receipt binding state does not match its proven prefix");
  const core = Object.freeze({
    schemaVersion: 2 as const,
    format: GHOSTGET_MESSAGING_RECEIPT_BINDING_V2_FORMAT,
    contractId: GHOSTGET_MESSAGING_RECEIPT_BINDING_V2_CONTRACT_ID,
    contractHash: GHOSTGET_MESSAGING_RECEIPT_BINDING_V2_CONTRACT_HASH,
    clientIntentSha256: intent.clientIntentSha256,
    contextBindingSha256: intent.contextBindingSha256,
    sourceConversationCoordinateSha256: intent.sourceConversationCoordinateSha256,
    routeRefSha256: intent.routeRefSha256,
    contextRefSha256: intent.contextRefSha256,
    turnDigest: intent.turnDigest,
    previewDigest: digest(input.previewDigest, "Ghostget receipt.previewDigest"),
    runId: text(input.runId, "Ghostget receipt.runId", 256),
    state: input.state,
    partCount: intent.partCount,
    provenPartCount,
    recordedAt: timestamp(input.recordedAt, "Ghostget receipt.recordedAt"),
  });
  return Object.freeze({
    ...core,
    receiptSha256: sha256(canonicalJson(core)),
  });
}

/** Exact #72 receipt shape retained only for compatibility tooling. */
export function createGhostgetMessagingReceiptBindingV1(input: Readonly<{
  context: unknown;
  clientIntent: unknown;
  previewDigest: unknown;
  runId: unknown;
  state: unknown;
  provenPartCount: unknown;
  recordedAt: unknown;
}>): GhostgetMessagingReceiptBindingV1 {
  const enriched = createGhostgetMessagingReceiptBindingV2(input);
  const core = Object.freeze({
    schemaVersion: 1 as const,
    format: GHOSTGET_MESSAGING_RECEIPT_BINDING_V1_FORMAT,
    contractId: GHOSTGET_MESSAGING_RECEIPT_BINDING_V1_CONTRACT_ID,
    contractHash: GHOSTGET_MESSAGING_RECEIPT_BINDING_V1_CONTRACT_HASH,
    clientIntentSha256: enriched.clientIntentSha256,
    routeRefSha256: enriched.routeRefSha256,
    contextRefSha256: enriched.contextRefSha256,
    turnDigest: enriched.turnDigest,
    previewDigest: enriched.previewDigest,
    runId: enriched.runId,
    state: enriched.state,
    partCount: enriched.partCount,
    provenPartCount: enriched.provenPartCount,
    recordedAt: enriched.recordedAt,
  });
  return Object.freeze({
    ...core,
    receiptSha256: sha256(canonicalJson(core)),
  });
}
