/** Canonical immutable Ghostget package release identity. */
export const GHOSTGET_VERSION = "0.18.44" as const;
