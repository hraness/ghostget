#!/usr/bin/env bun
import {
  adapterInstalledLines,
  authBoundLines,
  authListText,
  authSavedLines,
  writeAuthLines,
  type AuthOutputAudience,
  type AuthSummary,
} from "./auth-output";
import { browserProfilesResult } from "./browser-profiles-cli";
import { existsSync, lstatSync } from "node:fs";
import { join, resolve } from "node:path";

import { BoundedByteBuffer } from "@hraness/wordcell/clip/bounded-byte-buffer";
import {
  clipMain,
  inspectClipEnvironment,
  parseCaptureArguments,
  renderDoctorReport,
  type ClipRuntimeOptions,
} from "@hraness/wordcell/capture";
import { redactSensitiveText } from "@hraness/wordcell/clip/persist";
import { sanitizeTerminalLine, sanitizeTerminalText } from "@hraness/wordcell/clip/terminal";
import {
  createAuth,
  listAuth,
  loadAuth,
  loadAuthSnapshot,
  normalizeAuthDisplayName,
  removeAuth,
  replaceAuthIfUnchanged,
  saveAuth,
  type GhostgetAuth,
} from "./auth";
import { runAccountsDeviceLogin, runAccountsSignOut } from "./accounts-auth";
import {
  isPublicWebSessionInvocationAuthority,
  type InvocationAuthority,
} from "./web-session-authentication-policy";
import { parseGhostgetArguments, ghostgetUsage, type GhostgetArguments } from "./args";
import { GHOSTGET_COMMAND_NAMES, ghostgetHelpCommandFor } from "./usage";
import { cliSentence, cliStyle, closestCliName, renderCliError } from "./cli-style";
import {
  configureCookieAccessNotice,
  cookieAccessRemedy,
  CookieAccessSkippedError,
  detectCookieAudience,
  findCookieAccessError,
  terminalReadKey,
} from "./cookie-access";
import { stateKeychainNoticeRecord } from "./keychain-notice-record";
import type * as BeeperMessageLikeMeCliRuntimeModule from "./beeper-message-like-me-cli";
import type * as BeeperContactInteractionCliRuntimeModule from "./beeper-contact-interactions-cli";
import type * as ApplePhotosCliRuntimeModule from "./apple-photos-cli";
import type * as WhatsAppMessageLikeMeCliRuntimeModule from "./whatsapp-message-like-me-cli";
import type { BeeperMessageLikeMeProgress } from "./beeper-message-like-me-source";
import type { BeeperContactInteractionCliProgress } from "./beeper-contact-interactions-cli";
import type { WhatsAppMessageLikeMeCliProgress } from "./whatsapp-message-like-me-cli";
import type { GmailCaptureRunner } from "./gmail-capture";
import type * as MediaRuntimeModule from "./media";
import {
  cloneBrowserProfile,
  PreservedBrowserArtifactsError,
  profilePath,
} from "./browser";
import { runCaptureWithBrowserAdmission } from "./browser-admission";
import {
  createBrowserSnapshotDirectory,
  purgeOrphanedBrowserSnapshots,
  removeBrowserSnapshotDirectory,
} from "./browser-snapshots";
import {
  runCapabilities,
  runPluginList,
  runPluginShow,
} from "./catalog-cli";
import {
  runContractsCatalog,
  runContractsCheck,
  runContractsRepair,
  runContractsSchema,
  projectContractRepairSignal,
} from "./contracts-cli";
import { cacheContractRepairSignal } from "./contract-repair-inbox";
import { ContractCaptureRequiredError, type ContractRepairSignal } from "./contracts-repair";
import {
  discardDerivation,
  finishDerivation,
  listDerivations,
  reviewDerivation,
  runDerivationBrowserCommand,
  startDerivation,
} from "./derive";
import {
  parseDerivationReviewFieldNames,
  parseDerivationReviewFixtures,
  type DerivationReviewFieldNames,
  type DerivationReviewFixtures,
  type DerivationReviewSelection,
} from "./derive-review";
import { derivationFixtureSummaries } from "./derive-fixtures";
import { analyzeHarFile, emptyManifest, writeDerivationScaffold } from "./har";
import {
  canonicalJson,
  canonicalJsonSha256Matches,
  DOM_ACTION_TRANSPORT_DISABLED_MESSAGE,
  isProviderOperation,
  isLocalCliOperation,
  isReviewedTemplateOperation,
  isWebSessionOperation,
  manifestHash,
  sha256,
  GHOSTGET_LEGACY_LINKEDIN_MANIFEST_HASH,
  type OperationInput,
  type GhostgetOperation,
} from "./model";
import { getProviderContract, providerContractHash } from "./provider-contracts";
import {
  getLocalCliContract,
  localCliContractHash,
} from "./local-cli-contracts";
import { withLocalCliProviderCleanupAdmission } from "./local-cli-admission";
import {
  portableProviderPluginSubjectProbeIdentity,
  type LocalCliPluginBindingV1,
  type LinkedDevicePluginBindingV1,
  type ProviderPluginBindingV1,
  type ProviderPluginLinkedDeviceAttemptBoundaryV1,
  type ProviderPluginSubjectIdentityV1,
} from "./provider-plugin";
import {
  LEGACY_PORTABLE_PROVIDER_PLUGIN_MANIFEST_NAME,
  WRENCH_PORTABLE_PROVIDER_PLUGIN_MANIFEST_NAME,
  PORTABLE_PROVIDER_PLUGIN_MANIFEST_NAME,
} from "./provider-plugin-package";
import {
  acquirePortableProviderPluginInvocationLease,
  createPortableProviderPluginInvocationLeaseContainmentController,
  releasePortableProviderPluginInvocationLease,
} from "./provider-plugin-invocation-lease";
import { requireProviderPluginAuth } from "./provider-plugin-auth";
import { acquireReadProjectionAuthAdmission } from "./read-projection-admission";
import {
  recoverLinkedDeviceLifecycleAdmissions,
} from "./linked-device-lifecycle-admission";
import {
  readLinkedDeviceLifecycleJournal,
} from "./linked-device-lifecycle-journal";
import {
  LinkedDeviceLifecycleIndeterminateError,
  reconcileLinkedDeviceLifecycleJournal,
  recoverLinkedDeviceLifecycleJournals,
  runLinkedDevicePairLifecycle,
  runLinkedDeviceSyncOnceLifecycle,
} from "./linked-device-lifecycle-runtime";
import {
  checkPortableProviderPlugin,
  disablePortableProviderPlugin,
  doctorPortableProviderPlugins,
  initPortableProviderPlugin,
  installPortableProviderPlugin,
  packPortableProviderPlugin,
  portableProviderPluginStoreRoot,
  removePortableProviderPlugin,
  showPortableProviderPlugin,
  testPortableProviderPlugin,
} from "./provider-plugin-lifecycle";
import {
  assertPortableProviderPluginActivatable,
  assertPortableProviderPluginQuiescent,
} from "./provider-plugin-lifecycle-kernel";
import { createPortableProviderPluginCatalog } from "./provider-plugin-portable-catalog";
import type { ProviderPluginRegistry } from "./provider-plugin-registry";
import { withPortableProviderPluginCatalogLock } from "./provider-plugin-store";
import { providerPluginRegistry } from "./provider-plugins";
import {
  reconcilePortableProviderPluginRun,
  reconcilePortableProviderPluginRunFromReadback,
} from "./portable-run-recovery";
import type {
  PortableProviderPluginReadbackPort,
} from "./provider-plugin-portable-runtime";
import { getWebSessionContract, webSessionContractHash } from "./web-session-contracts";
import { isCookieCapableWebAuth, reviewedTemplateHash } from "./reviewed-template";
import {
  recoverWebSessionCleanupAdmissions,
} from "./web-session-cleanup-admission";
import {
  readFailureProjection,
  WEB_SESSION_CLEANUP_JOIN_TIMEOUT_MS,
} from "./web-session-execution";
import { reconcileWebSessionRun } from "./web-session-recovery";
import { loadOAuthCredential, loadOAuthToken, requireOAuthScopes } from "./provider-http";
import {
  installManagedGoogleOAuth,
  loginGoogleOAuth,
} from "./oauth-google";
import {
  compositionNames,
  platformSurfaceIds,
  semanticOperationNames,
  socialPlatformCatalog,
  splitWeightedThread,
  textWeightPolicies,
  weightedTextLength,
  type PlatformSurfaceCatalogEntry,
  type PlatformSurfaceId,
} from "./platform-catalog";
import { isPlanBoundFile, summarizePlanFile } from "./plan-assets";
import {
  cancelInvocationPlan,
  confirmMessagingInvocation,
  confirmInvocation,
  createAndSaveInvocationPlan,
  createReadProjectionQueryForInvocation,
  type createInvocationPlan,
  type executeReadInvocation,
  listInvocationPlans,
  listRunReceipts,
  prepareInvocation,
  prepareReadInvocation,
  loadInvocationPlan,
  purgeExpiredPlans,
  readRunReceipt,
  repairInterruptedConfirmationClaims,
  inspectConfirmedWriteIntentFences,
  repairInterruptedRunJournals,
  supersedeSettledDuplicateSources,
} from "./runtime";
import {
  readCachedPreparedCapability,
  revalidatePreparedCapability,
  type RevalidatedCapability,
} from "./read-client";
import type { ReadProjectionCacheResult } from "./read-projections";
import {
  identifyOmniView,
  readCachedOmniViewInternal,
  rebuildOmniViewFromExactCache,
  revalidateOmniViewInternal,
} from "./omni-runtime";
import {
  discoverMessagingRoutesInternal,
  loadMessagingPreviewForConfirmationInternal,
  previewMessagingTurnInternal,
  readMessagingContextInternal,
  reserveMessagingPrivateOutputPair,
  reconcileMessagingRunInternal,
  resolveMessagingRouteInternal,
  showMessagingRunInternal,
  validateMessagingPrivateOutputPath,
  writeMessagingPrivateOutput,
  writeReservedMessagingPrivateOutput,
} from "./messaging-runtime";
import { readMessagingRunIfPresent } from "./messaging-action-store";
import {
  checkSourceProviderPluginDirectory,
  scaffoldWebProvider,
} from "./scripts/scaffold-web-provider";
import {
  createPrivateJsonIfAbsent,
  installManifest,
  listInstalledManifests,
  loadInstalledDiagnosticManifestSnapshot,
  readDiagnosticManifestFile,
  readManifestFile,
  readRegularFile,
  removeInstalledManifest,
  ensurePrivateStateDirectory,
  ghostgetStateHome,
  writePrivateJson,
} from "./storage";

type Output = {
  readonly stdout: (value: string) => void;
  readonly stderr: (value: string) => void;
};

type MediaRuntime = typeof MediaRuntimeModule;
type BeeperMessageLikeMeCliRuntime = typeof BeeperMessageLikeMeCliRuntimeModule;
type BeeperContactInteractionCliRuntime =
  typeof BeeperContactInteractionCliRuntimeModule;
type ApplePhotosCliRuntime = typeof ApplePhotosCliRuntimeModule;
type WhatsAppMessageLikeMeCliRuntime = typeof WhatsAppMessageLikeMeCliRuntimeModule;
type ImsgDirectInstallRuntime =
  typeof import("./providers/imessage-direct-install");

/**
 * Ghostget's stable boundary around the independently versioned Wordcell doctor.
 *
 * The default adapter preserves the complete Wordcell report for JSON output while
 * keeping its concrete schema and terminal renderer out of Ghostget's dependency
 * and test contracts.
 */
export type GhostgetClipEnvironmentInspection = {
  readonly report: unknown;
  readonly renderReport: () => string;
  readonly browserCaptureBootstrapReady: boolean;
};

const defaultOutput: Output = {
  stdout: (value) => process.stdout.write(value),
  stderr: (value) => process.stderr.write(value),
};

/**
 * Who reads this command's output. Only the real terminal counts as a TTY, so
 * captured output (tests, the SDK) is `quiet` unless HRANESS_AUDIENCE says
 * otherwise.
 */
function outputAudience(
  environment: Readonly<Record<string, string | undefined>>,
  output: Output,
): AuthOutputAudience {
  return detectCookieAudience(environment, output === defaultOutput && process.stderr.isTTY === true);
}

function outputStyle(environment: Readonly<Record<string, string | undefined>>, output: Output) {
  return cliStyle(environment, output === defaultOutput && process.stdout.isTTY === true);
}

function authSummary(auth: GhostgetAuth): AuthSummary {
  // Profiles and subjects come from browsers and providers; sanitize them.
  const subject = auth.subject === undefined ? {} : { subject: safe(auth.subject) };
  switch (auth.kind) {
    case "cookie-source":
      return { kind: auth.kind, id: auth.id, source: auth.source, ...(auth.profile === undefined ? {} : { profile: safe(auth.profile) }), ...(auth.displayName === undefined ? {} : { displayName: safe(auth.displayName) }), ...subject };
    case "browser-profile":
      return { kind: auth.kind, id: auth.id, ...(auth.cookieSource === undefined ? {} : { cookieSource: auth.cookieSource }), ...subject };
    case "oauth-token-file":
      return { kind: auth.kind, id: auth.id, provider: auth.provider, ...subject };
    case "linked-device-store":
      return { kind: auth.kind, id: auth.id, provider: auth.provider, ...subject };
    default:
      return { kind: "cookies-file", id: auth.id, ...subject };
  }
}

const loadMediaRuntime = (): Promise<MediaRuntime> => import("./media");
const loadBeeperMessageLikeMeCliRuntime = (): Promise<BeeperMessageLikeMeCliRuntime> =>
  import("./beeper-message-like-me-cli");
const loadBeeperContactInteractionCliRuntime = (): Promise<BeeperContactInteractionCliRuntime> =>
  import("./beeper-contact-interactions-cli");
const loadApplePhotosCliRuntime = (): Promise<ApplePhotosCliRuntime> =>
  import("./apple-photos-cli");
const loadWhatsAppMessageLikeMeCliRuntime = (): Promise<WhatsAppMessageLikeMeCliRuntime> =>
  import("./whatsapp-message-like-me-cli");
const loadImsgDirectInstallRuntime = (): Promise<ImsgDirectInstallRuntime> =>
  import("./providers/imessage-direct-install");

const runDefaultGmailCapture: GmailCaptureRunner = async (...arguments_) => {
  const { runGmailCapture } = await import("./gmail-capture");
  return runGmailCapture(...arguments_);
};

const inspectDefaultClipEnvironment = async (): Promise<GhostgetClipEnvironmentInspection> => {
  const report = await inspectClipEnvironment();
  return {
    report,
    renderReport: () => renderDoctorReport(report),
    browserCaptureBootstrapReady: report.deriveClient.status === "ready"
      && report.dependencies.find(
        (dependency) => dependency.name === "agent-browser",
      )?.status === "ready"
      && report.dependencies.find(
        (dependency) => dependency.name === "@steipete/sweet-cookie",
      )?.status === "ready",
  };
};

export function renderGhostgetUsage(): string {
  return ghostgetUsage;
}

/**
 * One-line usage error plus the per-command help to read next. The full help
 * never follows a usage error.
 */
/** The one sentence and one next command for a usage error, before styling. */
export function ghostgetUsageErrorParts(
  message: string,
  rawArguments: readonly string[],
): { readonly message: string; readonly next: string } {
  const first = rawArguments[0] ?? "";
  if (message === `unknown command: ${first}`) {
    const shown = safe(first).slice(0, 64);
    const suggestion = closestCliName(first, GHOSTGET_COMMAND_NAMES);
    return {
      message: `Unknown command "${shown}".${suggestion === null ? "" : ` Did you mean "${suggestion}"?`}`,
      next: "ghostget --help",
    };
  }
  return { message: cliSentence(safe(message)), next: ghostgetHelpCommandFor(rawArguments) };
}

export function renderGhostgetUsageError(
  message: string,
  rawArguments: readonly string[],
  environment: Readonly<Record<string, string | undefined>>,
  isTTY: boolean = process.stderr.isTTY === true,
): string {
  const parts = ghostgetUsageErrorParts(message, rawArguments);
  return renderCliError(cliStyle(environment, isTTY), parts.message, parts.next);
}

/**
 * `--json` and agents read errors as one JSON document on stdout, with the
 * same exit code: `{"ok":false,"error":{"code","message","next"}}`.
 */
export function wantsJsonErrors(
  rawArguments: readonly string[],
  environment: Readonly<Record<string, string | undefined>>,
  stderrIsTTY: boolean,
): boolean {
  return rawArguments.includes("--json") || detectCookieAudience(environment, stderrIsTTY) === "agent";
}

export function ghostgetErrorJson(code: string, message: string, next: string): string {
  return `${JSON.stringify({ ok: false, error: { code, message, next } })}\n`;
}

/** The command to run again after a permission denial. */
export function cookieAccessNext(arguments_: GhostgetArguments): string {
  // Keep the flags that change what the retry does or prints.
  if (arguments_.command === "auth-bind") {
    return `ghostget auth bind ${arguments_.id} --site ${arguments_.site}${arguments_.force ? " --force" : ""}${arguments_.json ? " --json" : ""}`;
  }
  return "ghostget doctor";
}

/**
 * Explain a keychain or Full Disk Access denial as a denial, never as missing
 * cookies. Returns null when the error is not a browser permission failure.
 */
export function renderCookieAccessFailure(
  error: unknown,
  arguments_: GhostgetArguments,
  environment: Readonly<Record<string, string | undefined>>,
  output: Output,
  stderrIsTTY: boolean = process.stderr.isTTY === true,
): number | null {
  const skipped = error instanceof CookieAccessSkippedError ? error : null;
  const denied = skipped === null ? findCookieAccessError(error) : null;
  if (skipped === null && denied === null) return null;
  const next = cookieAccessNext(arguments_);
  const json = ("json" in arguments_ && arguments_.json === true)
    || detectCookieAudience(environment, stderrIsTTY) === "agent";
  if (json) {
    output.stdout(`${JSON.stringify({
      ok: false,
      error: denied === null
        ? { code: "permission-skipped", kind: "keychain", message: `${safe(skipped!.message)}.`, next, settingsUrl: null }
        : {
            code: denied.code === "KEYCHAIN_UNAVAILABLE" ? "permission-unknown" : "permission-denied",
            kind: denied.permission,
            reason: denied.code,
            message: `${safe(denied.message)}.`,
            next,
            settingsUrl: denied.settingsUrl,
          },
    })}\n`);
    return 3;
  }
  const style = cliStyle(environment, stderrIsTTY);
  if (denied === null) {
    output.stderr(`${style.symbol("fail")} ${safe(skipped!.message)}.\n${style.symbol("next")} ${next}\n`);
    return 3;
  }
  output.stderr(
    `${style.symbol("fail")} ${safe(denied.message)}.\n  ${cookieAccessRemedy(denied)}\n${style.symbol("next")} ${next}\n`,
  );
  return 3;
}

export type GhostgetDependencies = {
  readonly clipMain: typeof clipMain;
  readonly runCapture: typeof runCaptureWithBrowserAdmission;
  readonly gmailCaptureMain: GmailCaptureRunner;
  readonly inspectClipEnvironment: () => Promise<GhostgetClipEnvironmentInspection>;
  readonly loadMediaRuntime: () => Promise<MediaRuntime>;
  readonly loadBeeperMessageLikeMeCliRuntime:
    () => Promise<BeeperMessageLikeMeCliRuntime>;
  readonly loadBeeperContactInteractionCliRuntime:
    () => Promise<BeeperContactInteractionCliRuntime>;
  readonly loadApplePhotosCliRuntime: () => Promise<ApplePhotosCliRuntime>;
  readonly loadWhatsAppMessageLikeMeCliRuntime:
    () => Promise<WhatsAppMessageLikeMeCliRuntime>;
  readonly loadImsgDirectInstallRuntime:
    () => Promise<ImsgDirectInstallRuntime>;
  readonly providerPluginRegistry: ProviderPluginRegistry;
  /**
   * Invokes a portable write's declared readback. Set only with the portable
   * catalog that also extended `providerPluginRegistry`.
   */
  readonly portableProviderPluginReadback?: PortableProviderPluginReadbackPort;
  /** A bare subject return means the runtime resolves no human handle. */
  readonly probePluginSubject: (
    binding: ProviderPluginBindingV1,
    auth: GhostgetAuth,
    signal?: AbortSignal,
    registry?: ProviderPluginRegistry,
    environment?: Readonly<Record<string, string | undefined>>,
  ) => Promise<string | ProviderPluginSubjectIdentityV1>;
  /** Test seam after subject validation and before the auth snapshot CAS. */
  readonly beforeAuthBindCommit: () => void | Promise<void>;
  readonly pairLinkedDeviceAuth: (
    binding: LinkedDevicePluginBindingV1,
    auth: GhostgetAuth,
    options: {
      readonly phone?: string;
      readonly environment: Readonly<Record<string, string | undefined>>;
      readonly attempt: ProviderPluginLinkedDeviceAttemptBoundaryV1;
    },
  ) => Promise<string>;
  readonly syncLinkedDeviceAuthOnce: (
    binding: LinkedDevicePluginBindingV1,
    auth: GhostgetAuth,
    options: {
      readonly environment: Readonly<Record<string, string | undefined>>;
      readonly attempt: ProviderPluginLinkedDeviceAttemptBoundaryV1;
    },
  ) => Promise<{
    readonly itemsStored: number;
    readonly projection: string;
    readonly emitsProtocolAcknowledgements: boolean;
  }>;
  readonly reconcileWebSessionRun: typeof reconcileWebSessionRun;
  readonly reconcileLinkedDeviceLifecycleJournal:
    typeof reconcileLinkedDeviceLifecycleJournal;
  readonly reconcilePortableProviderPluginRun:
    typeof reconcilePortableProviderPluginRun;
  readonly createPortableProviderPluginCatalog:
    typeof createPortableProviderPluginCatalog;
  readonly readCachedPreparedCapability:
    typeof readCachedPreparedCapability;
  readonly revalidatePreparedCapability:
    typeof revalidatePreparedCapability;
  readonly identifyOmniView: typeof identifyOmniView;
  readonly readCachedOmniViewInternal: typeof readCachedOmniViewInternal;
  readonly rebuildOmniViewFromExactCache: typeof rebuildOmniViewFromExactCache;
  readonly revalidateOmniViewInternal: typeof revalidateOmniViewInternal;
};

const defaultDependencies: GhostgetDependencies = {
  clipMain,
  runCapture: runCaptureWithBrowserAdmission,
  gmailCaptureMain: runDefaultGmailCapture,
  inspectClipEnvironment: inspectDefaultClipEnvironment,
  loadMediaRuntime,
  loadBeeperMessageLikeMeCliRuntime,
  loadBeeperContactInteractionCliRuntime,
  loadApplePhotosCliRuntime,
  loadWhatsAppMessageLikeMeCliRuntime,
  loadImsgDirectInstallRuntime,
  providerPluginRegistry,
  probePluginSubject: async (
    binding,
    auth,
    signal,
    registry = providerPluginRegistry,
    environment = process.env,
  ) => {
    requireProviderPluginAuth(binding, auth);
    const probe = binding.subject.probe;
    if (probe === undefined) {
      throw new Error(
        `provider plugin surface ${binding.surfaceId} has no current-account probe`,
      );
    }
    const probed = binding.transport === "local-cli"
      ? await withLocalCliProviderCleanupAdmission(
          {
            registry,
            binding,
            auth,
            purpose: { kind: "subject-probe" },
            environment,
          },
          (registerCleanupBarrier) => probe(auth, {
            ...(signal === undefined ? {} : { signal }),
            environment,
            registerCleanupBarrier,
          }),
        )
      : binding.subject.probeIdentity !== undefined
        ? await binding.subject.probeIdentity(
            auth,
            signal === undefined ? undefined : { signal, environment },
          )
        : await probe(
            auth,
            signal === undefined ? undefined : { signal, environment },
          );
    const subject = typeof probed === "string" ? probed : probed.subject;
    if (!binding.subject.matches(subject)) {
      throw new Error(
        `provider plugin surface ${binding.surfaceId} returned a subject outside ${binding.subject.format}`,
      );
    }
    return probed;
  },
  beforeAuthBindCommit: () => undefined,
  pairLinkedDeviceAuth: async (binding, auth, options) => {
    const lifecycle = binding.linkedDeviceLifecycle;
    if (lifecycle === undefined) {
      throw new Error(
        `linked-device plugin surface ${binding.surfaceId} does not declare pairing`,
      );
    }
    return lifecycle.pair(auth, options);
  },
  syncLinkedDeviceAuthOnce: async (binding, auth, options) => {
    const lifecycle = binding.linkedDeviceLifecycle;
    if (lifecycle === undefined) {
      throw new Error(
        `linked-device plugin surface ${binding.surfaceId} does not declare one-shot sync`,
      );
    }
    return lifecycle.syncOnce(auth, options);
  },
  reconcileWebSessionRun,
  reconcileLinkedDeviceLifecycleJournal,
  reconcilePortableProviderPluginRun,
  createPortableProviderPluginCatalog,
  readCachedPreparedCapability,
  revalidatePreparedCapability,
  identifyOmniView,
  readCachedOmniViewInternal,
  rebuildOmniViewFromExactCache,
  revalidateOmniViewInternal,
};

function resolveDependencies(overrides: Partial<GhostgetDependencies>): GhostgetDependencies {
  return {
    clipMain: overrides.clipMain ?? defaultDependencies.clipMain,
    runCapture: overrides.runCapture ?? defaultDependencies.runCapture,
    gmailCaptureMain:
      overrides.gmailCaptureMain ?? defaultDependencies.gmailCaptureMain,
    inspectClipEnvironment: overrides.inspectClipEnvironment ?? defaultDependencies.inspectClipEnvironment,
    loadMediaRuntime: overrides.loadMediaRuntime ?? defaultDependencies.loadMediaRuntime,
    loadBeeperMessageLikeMeCliRuntime:
      overrides.loadBeeperMessageLikeMeCliRuntime
      ?? defaultDependencies.loadBeeperMessageLikeMeCliRuntime,
    loadBeeperContactInteractionCliRuntime:
      overrides.loadBeeperContactInteractionCliRuntime
      ?? defaultDependencies.loadBeeperContactInteractionCliRuntime,
    loadApplePhotosCliRuntime:
      overrides.loadApplePhotosCliRuntime
      ?? defaultDependencies.loadApplePhotosCliRuntime,
    loadWhatsAppMessageLikeMeCliRuntime:
      overrides.loadWhatsAppMessageLikeMeCliRuntime
      ?? defaultDependencies.loadWhatsAppMessageLikeMeCliRuntime,
    loadImsgDirectInstallRuntime:
      overrides.loadImsgDirectInstallRuntime
      ?? defaultDependencies.loadImsgDirectInstallRuntime,
    providerPluginRegistry: overrides.providerPluginRegistry
      ?? defaultDependencies.providerPluginRegistry,
    probePluginSubject: overrides.probePluginSubject
      ?? defaultDependencies.probePluginSubject,
    beforeAuthBindCommit: overrides.beforeAuthBindCommit
      ?? defaultDependencies.beforeAuthBindCommit,
    pairLinkedDeviceAuth: overrides.pairLinkedDeviceAuth
      ?? defaultDependencies.pairLinkedDeviceAuth,
    syncLinkedDeviceAuthOnce: overrides.syncLinkedDeviceAuthOnce
      ?? defaultDependencies.syncLinkedDeviceAuthOnce,
    reconcileWebSessionRun: overrides.reconcileWebSessionRun ?? defaultDependencies.reconcileWebSessionRun,
    reconcileLinkedDeviceLifecycleJournal:
      overrides.reconcileLinkedDeviceLifecycleJournal
      ?? defaultDependencies.reconcileLinkedDeviceLifecycleJournal,
    reconcilePortableProviderPluginRun:
      overrides.reconcilePortableProviderPluginRun
      ?? defaultDependencies.reconcilePortableProviderPluginRun,
    createPortableProviderPluginCatalog:
      overrides.createPortableProviderPluginCatalog
      ?? defaultDependencies.createPortableProviderPluginCatalog,
    readCachedPreparedCapability:
      overrides.readCachedPreparedCapability
      ?? defaultDependencies.readCachedPreparedCapability,
    revalidatePreparedCapability:
      overrides.revalidatePreparedCapability
      ?? defaultDependencies.revalidatePreparedCapability,
    identifyOmniView:
      overrides.identifyOmniView ?? defaultDependencies.identifyOmniView,
    readCachedOmniViewInternal:
      overrides.readCachedOmniViewInternal
      ?? defaultDependencies.readCachedOmniViewInternal,
    rebuildOmniViewFromExactCache:
      overrides.rebuildOmniViewFromExactCache
      ?? defaultDependencies.rebuildOmniViewFromExactCache,
    revalidateOmniViewInternal:
      overrides.revalidateOmniViewInternal
      ?? defaultDependencies.revalidateOmniViewInternal,
  };
}

function safe(value: string): string {
  return sanitizeTerminalLine(redactSensitiveText(value));
}

function safeJson(value: unknown): string {
  return `${JSON.stringify(value, (_key, candidate: unknown) =>
    typeof candidate === "string" ? sanitizeTerminalText(redactSensitiveText(candidate)) : candidate, 2)}\n`;
}

const MAX_CLI_RECOVERY_HANDLE_BYTES = 8 * 1024;

function boundedCliRecoveryHandle(value: string): string | null {
  if (
    value.length < 1
    || Buffer.byteLength(value, "utf8") > MAX_CLI_RECOVERY_HANDLE_BYTES
  ) return null;
  return /^[A-Za-z0-9_./:;=+-]+$/u.test(value) ? value : null;
}

function exactTerminalJson(value: unknown): string {
  const json = JSON.stringify(value, null, 2);
  // JSON escapes preserve the exact value when the document is parsed,
  // while keeping terminal-control and bidi characters inert on screen.
  return `${json.replace(/[\u007f-\u009f\u061c\u200e\u200f\u2028-\u202e\u2066-\u2069]/gu, (character) =>
    `\\u${character.charCodeAt(0).toString(16).padStart(4, "0")}`)}\n`;
}

function print(output: Output, value: unknown, json: boolean): void {
  if (json) { output.stdout(safeJson(value)); return; }
  // A serialized structure keeps its line breaks; only a single line is
  // collapsed. Line sanitization used to flatten `auth list` into one row.
  output.stdout(typeof value === "string"
    ? `${safe(value)}\n`
    : `${sanitizeTerminalText(redactSensitiveText(JSON.stringify(value, null, 2)))}\n`);
}

function beeperProgressInteger(value: number, minimum: number): number {
  if (!Number.isSafeInteger(value) || value < minimum) {
    throw new Error("Beeper export progress was invalid");
  }
  return value;
}

function beeperProgressPosition(
  progress: Readonly<{ account: number; accounts: number }>,
): string {
  const account = beeperProgressInteger(progress.account, 1);
  const accounts = beeperProgressInteger(progress.accounts, 1);
  if (account > accounts) throw new Error("Beeper export progress was invalid");
  return `${account}/${accounts}`;
}

function plural(count: number, singular: string, plural_: string): string {
  return count === 1 ? singular : plural_;
}

function renderBeeperMessageLikeMeProgress(
  progress: BeeperMessageLikeMeProgress | BeeperContactInteractionCliProgress,
): string {
  if (progress.phase === "recovery-started") {
    return "ghostget: Beeper export: checking prior private export state\n";
  }
  if (progress.phase === "recovery-completed") {
    const recovered = beeperProgressInteger(progress.recovered, 0);
    const published = beeperProgressInteger(progress.published, 0);
    return `ghostget: Beeper export: private recovery complete; ${recovered} ${plural(recovered, "directory", "directories")} reclaimed, ${published} published ${plural(published, "bundle", "bundles")} preserved\n`;
  }
  if (progress.phase === "preparing") {
    return "ghostget: Beeper export: preparing pinned official CLI\n";
  }
  if (progress.phase === "accounts-discovered") {
    const accounts = beeperProgressInteger(progress.accounts, 1);
    return `ghostget: Beeper export: ${accounts} ${plural(accounts, "account", "accounts")} discovered\n`;
  }
  if (progress.phase === "accounts-progress") {
    if (progress.stage !== "discovering" && progress.stage !== "verifying") {
      throw new Error("Beeper export progress was invalid");
    }
    const elapsedSeconds = beeperProgressInteger(progress.elapsedSeconds, 0);
    const action = progress.stage === "discovering"
      ? "discovering accounts"
      : "verifying connected accounts";
    return `ghostget: Beeper export: ${action}; ${elapsedSeconds}s elapsed\n`;
  }
  if (progress.phase === "account-started") {
    return `ghostget: Beeper export: account ${beeperProgressPosition(progress)} started\n`;
  }
  if (progress.phase === "account-validating") {
    const elapsedSeconds = beeperProgressInteger(progress.elapsedSeconds, 0);
    return `ghostget: Beeper export: account ${beeperProgressPosition(progress)} validating; ${elapsedSeconds}s elapsed\n`;
  }
  if (progress.phase === "account-progress") {
    const elapsedSeconds = beeperProgressInteger(progress.elapsedSeconds, 0);
    return `ghostget: Beeper export: account ${beeperProgressPosition(progress)} running; ${elapsedSeconds}s elapsed\n`;
  }
  if (progress.phase === "account-skipped") {
    if (progress.reason !== "chat-limit-reached") {
      throw new Error("Beeper export progress was invalid");
    }
    return `ghostget: Beeper export: account ${beeperProgressPosition(progress)} skipped; chat limit reached\n`;
  }
  if (progress.phase === "account-completed") {
    const chats = beeperProgressInteger(progress.chats, 0);
    const messages = beeperProgressInteger(progress.messages, 0);
    return `ghostget: Beeper export: account ${beeperProgressPosition(progress)} complete; ${chats} ${plural(chats, "chat", "chats")}, ${messages} ${plural(messages, "message", "messages")} total\n`;
  }
  if (progress.phase === "accounts-verifying") {
    const accounts = beeperProgressInteger(progress.accounts, 1);
    return `ghostget: Beeper export: verifying ${accounts} connected ${plural(accounts, "account", "accounts")}\n`;
  }
  if (progress.phase === "conversion-started") {
    const accounts = beeperProgressInteger(progress.accounts, 1);
    const chats = beeperProgressInteger(progress.chats, 0);
    const messages = beeperProgressInteger(progress.messages, 0);
    return `ghostget: Beeper export: converting ${accounts} ${plural(accounts, "account", "accounts")}; ${chats} ${plural(chats, "chat", "chats")}, ${messages} ${plural(messages, "message", "messages")} total\n`;
  }
  if (progress.phase === "conversion-progress") {
    const elapsedSeconds = beeperProgressInteger(progress.elapsedSeconds, 0);
    return `ghostget: Beeper export: converting local bundle; ${elapsedSeconds}s elapsed\n`;
  }
  if (progress.phase === "bundle-building") {
    const elapsedSeconds = beeperProgressInteger(progress.elapsedSeconds, 0);
    const records = beeperProgressInteger(progress.records, 0);
    const bytes = beeperProgressInteger(progress.bytes, 0);
    return `ghostget: Beeper export: building local bundle; ${records} ${plural(records, "record", "records")}, ${bytes} bytes; ${elapsedSeconds}s elapsed\n`;
  }
  if (progress.phase === "bundle-validating") {
    const elapsedSeconds = beeperProgressInteger(progress.elapsedSeconds, 0);
    const records = beeperProgressInteger(progress.records, 0);
    const bytes = beeperProgressInteger(progress.bytes, 0);
    return `ghostget: Beeper export: validating local bundle; ${records} ${plural(records, "record", "records")}, ${bytes} bytes; ${elapsedSeconds}s elapsed\n`;
  }
  if (progress.phase === "bundle-publishing") {
    const elapsedSeconds = beeperProgressInteger(progress.elapsedSeconds, 0);
    const records = beeperProgressInteger(progress.records, 0);
    const bytes = beeperProgressInteger(progress.bytes, 0);
    return `ghostget: Beeper export: publishing local bundle atomically; ${records} ${plural(records, "record", "records")}, ${bytes} bytes; ${elapsedSeconds}s elapsed\n`;
  }
  if (progress.phase === "private-cleanup") {
    const elapsedSeconds = beeperProgressInteger(progress.elapsedSeconds, 0);
    return `ghostget: Beeper export: removing private raw shards; ${elapsedSeconds}s elapsed\n`;
  }
  if (progress.phase === "summary-building") {
    const elapsedSeconds = beeperProgressInteger(progress.elapsedSeconds, 0);
    const records = beeperProgressInteger(progress.records, 0);
    return `ghostget: Beeper export: deriving body-free relationship summary; ${records} ${plural(records, "record", "records")}; ${elapsedSeconds}s elapsed\n`;
  }
  if (progress.phase === "summary-completed") {
    const records = beeperProgressInteger(progress.records, 0);
    const relationships = beeperProgressInteger(progress.relationships, 0);
    const interactions = beeperProgressInteger(progress.interactions, 0);
    return `ghostget: Beeper export: body-free summary complete; ${relationships} ${plural(relationships, "relationship", "relationships")}, ${interactions} ${plural(interactions, "interaction", "interactions")} from ${records} ${plural(records, "record", "records")}\n`;
  }
  const exhaustive: never = progress;
  void exhaustive;
  throw new Error("Beeper export progress was invalid");
}

function renderWhatsAppMessageLikeMeProgress(
  progress: WhatsAppMessageLikeMeCliProgress,
): string {
  const integer = (value: number): number => {
    if (!Number.isSafeInteger(value) || value < 0) {
      throw new Error("WhatsApp export progress was invalid");
    }
    return value;
  };
  if (progress.phase === "recovery-started") {
    return "ghostget: WhatsApp export: checking prior private export state\n";
  }
  if (progress.phase === "recovery-completed") {
    const recovered = integer(progress.recovered);
    const published = integer(progress.published);
    return `ghostget: WhatsApp export: private recovery complete; ${recovered} ${plural(recovered, "directory", "directories")} reclaimed, ${published} published ${plural(published, "bundle", "bundles")} preserved\n`;
  }
  if (progress.phase === "preparing") {
    return "ghostget: WhatsApp export: binding the quiescent local store\n";
  }
  if (progress.phase === "page-started" || progress.phase === "page-completed") {
    const page = integer(progress.page);
    const messages = integer(progress.messages);
    const state = progress.phase === "page-started" ? "reading" : "completed";
    return `ghostget: WhatsApp export: page ${page} ${state}; ${messages} local message rows observed\n`;
  }
  if (progress.phase === "conversion-completed") {
    return `ghostget: WhatsApp export: local projection complete; ${integer(progress.messages)} rows, ${integer(progress.conversations)} conversations, ${integer(progress.participants)} participants\n`;
  }
  if (progress.phase === "v2-conversion") {
    return `ghostget: WhatsApp export: publishing bundle v2 artifact ${integer(progress.artifact)}/${integer(progress.artifacts)}; ${integer(progress.records)} records converted\n`;
  }
  if (
    progress.phase === "bundle-building"
    || progress.phase === "bundle-validating"
    || progress.phase === "bundle-publishing"
  ) {
    const action = progress.phase === "bundle-building"
      ? "building"
      : progress.phase === "bundle-validating"
        ? "validating"
        : "publishing";
    return `ghostget: WhatsApp export: ${action} private bundle; ${integer(progress.records)} records, ${integer(progress.bytes)} bytes; ${integer(progress.elapsedSeconds)}s elapsed\n`;
  }
  if (progress.phase === "private-cleanup") {
    return `ghostget: WhatsApp export: cleaning private validation state; ${integer(progress.elapsedSeconds)}s elapsed\n`;
  }
  const exhaustive: never = progress;
  void exhaustive;
  throw new Error("WhatsApp export progress was invalid");
}

type PreparedCapture = {
  readonly arguments: readonly string[];
  readonly runtimeOptions: ClipRuntimeOptions;
  readonly cleanup: () => void;
};

type ResolvedCapture = {
  readonly arguments: readonly string[];
  readonly auth?: GhostgetAuth;
};

function resolveCaptureArgumentsWithAuth(
  arguments_: readonly string[],
  environment: Readonly<Record<string, string | undefined>>,
): ResolvedCapture {
  const forwarded: string[] = [];
  let authId: string | undefined;
  for (let index = 0; index < arguments_.length; index += 1) {
    const argument = arguments_[index];
    if (argument !== "--auth") {
      forwarded.push(argument ?? "");
      continue;
    }
    const value = arguments_[index + 1];
    if (value === undefined || value.startsWith("--")) throw new Error("--auth requires a stored auth locator ID");
    if (authId !== undefined) throw new Error("capture accepts at most one --auth locator");
    authId = value;
    index += 1;
  }
  if (authId === undefined) return { arguments: forwarded };
  const explicitAuthFlags = new Set(["--browser-profile", "--cookie-source", "--cookie-profile", "--cookies-file"]);
  if (forwarded.some((argument) => explicitAuthFlags.has(argument))) {
    throw new Error("--auth cannot be combined with raw browser-profile or cookie-source options");
  }
  const auth = loadAuth(authId, environment);
  if (auth.kind === "oauth-token-file") {
    if (auth.provider === "gmail") {
      return { arguments: forwarded, auth };
    }
    throw new Error(
      `auth locator ${auth.id} is for official ${auth.provider} API capabilities and cannot be used for browser capture; use cookie/profile auth for clip or read`,
    );
  }
  if (auth.kind === "linked-device-store") {
    throw new Error(
      `auth locator ${auth.id} is a ${auth.provider} linked-device protocol realm and cannot be used for browser capture`,
    );
  }
  if (auth.kind === "cookie-source") {
    return {
      arguments: [
        ...forwarded,
        "--cookie-source", auth.source,
        ...(auth.profile === undefined ? [] : ["--cookie-profile", auth.profile]),
      ],
      auth,
    };
  }
  if (auth.kind === "cookies-file") {
    return {
      arguments: [...forwarded, "--cookies-file", auth.path],
      auth,
    };
  }
  return {
    arguments: [
      ...forwarded,
      "--browser-profile", auth.profile,
      ...(auth.cookieSource === undefined ? [] : ["--cookie-source", auth.cookieSource]),
      ...(auth.cookieProfile === undefined ? [] : ["--cookie-profile", auth.cookieProfile]),
    ],
    auth,
  };
}

function prepareCapture(
  resolved: ResolvedCapture,
  environment: Readonly<Record<string, string | undefined>>,
): PreparedCapture {
  const auth = resolved.auth;
  if (auth?.kind !== "browser-profile") {
    return { arguments: resolved.arguments, runtimeOptions: {}, cleanup: () => undefined };
  }
  const sourceProfile = profilePath(auth.profile);
  if (sourceProfile === null) {
    return {
      arguments: resolved.arguments,
      runtimeOptions: auth.browserExecutable === undefined
        ? {}
        : { browserExecutable: auth.browserExecutable },
      cleanup: () => undefined,
    };
  }
  const privateDirectory = createBrowserSnapshotDirectory(environment);
  try {
    const cloned = cloneBrowserProfile(sourceProfile, privateDirectory.path);
    const clonedArguments = [...resolved.arguments];
    const profileIndex = clonedArguments.indexOf("--browser-profile");
    if (profileIndex < 0 || clonedArguments[profileIndex + 1] !== auth.profile) {
      throw new Error("resolved browser-profile auth does not match its capture arguments");
    }
    clonedArguments[profileIndex + 1] = cloned.userDataPath;
    return {
      arguments: clonedArguments,
      runtimeOptions: {
        ...(auth.browserExecutable === undefined
          ? {}
          : { browserExecutable: auth.browserExecutable }),
        ownedBrowserProfile: {
          path: cloned.userDataPath,
          ...(cloned.profileDirectory === undefined ? {} : { profileDirectory: cloned.profileDirectory }),
        },
      },
      cleanup: () => removeBrowserSnapshotDirectory(privateDirectory, environment),
    };
  } catch (error) {
    removeBrowserSnapshotDirectory(privateDirectory, environment);
    throw error;
  }
}

async function runCaptureCommand(
  prefix: readonly string[],
  arguments_: readonly string[],
  environment: Readonly<Record<string, string | undefined>>,
  output: Output,
  dependencies: GhostgetDependencies,
  signal?: AbortSignal,
  onUsefulResult?: () => void,
): Promise<number> {
  const resolved = resolveCaptureArgumentsWithAuth(arguments_, environment);
  const unresolvedArguments = [...prefix, ...resolved.arguments];
  const parsed = parseCaptureArguments(unresolvedArguments, environment);
  if (!parsed.ok) {
    return dependencies.clipMain(unresolvedArguments, environment, output);
  }
  if (
    resolved.auth?.kind === "oauth-token-file"
    && resolved.auth.provider === "gmail"
    && (parsed.value.command === "capture" || parsed.value.command === "inspect")
  ) {
    const hasExplicitMedia = resolved.arguments.includes("--media");
    const normalizedGmailArguments = parsed.value.media === "images" && !hasExplicitMedia
      ? { ...parsed.value, media: "all" as const }
      : parsed.value;
    const hasExplicitOutput = resolved.arguments.includes("--output");
    const persistentPrivateCapture = !normalizedGmailArguments.stdout && !hasExplicitOutput;
    const gmailOptions = persistentPrivateCapture
      ? {
          ...normalizedGmailArguments,
          outputBase: join(ghostgetStateHome(environment), "captures", "gmail"),
        }
      : normalizedGmailArguments;
    if (persistentPrivateCapture) {
      ensurePrivateStateDirectory(gmailOptions.outputBase, environment);
    }
    const code = await dependencies.gmailCaptureMain(
      gmailOptions,
      resolved.auth,
      environment,
      output,
    );
    if (code === 0) onUsefulResult?.();
    return code;
  }
  const prepared = prepareCapture(resolved, environment);
  try {
    const code = await dependencies.clipMain(
      [...prefix, ...prepared.arguments],
      environment,
      output,
      {
        runCapture: (captureArguments) => dependencies.runCapture(
          captureArguments,
          environment,
          signal === undefined ? {} : { signal },
        ),
      },
      prepared.runtimeOptions,
    );
    if (code === 0 && (parsed.value.command === "capture" || parsed.value.command === "inspect")) onUsefulResult?.();
    return code;
  } finally {
    prepared.cleanup();
  }
}

async function readStdinBounded(maxBytes: number): Promise<string> {
  const reader = Bun.stdin.stream().getReader();
  const output = new BoundedByteBuffer(maxBytes);
  try {
    for (;;) {
      const next = await reader.read();
      if (next.done) break;
      if (!output.append(next.value)) throw new Error(`stdin exceeds ${maxBytes} bytes`);
    }
  } finally {
    reader.releaseLock();
  }
  return new TextDecoder("utf-8", { fatal: true }).decode(output.toUint8Array());
}

async function readInput(source: string): Promise<unknown> {
  const maximum = 1024 * 1024;
  let text = source;
  if (source === "-") text = await readStdinBounded(maximum);
  else if (source.startsWith("@")) {
    const path = resolve(source.slice(1));
    text = readRegularFile(path, maximum, "input file");
  } else if (Buffer.byteLength(source, "utf8") > maximum) throw new Error(`inline input exceeds ${maximum} bytes`);
  return JSON.parse(text) as unknown;
}

async function readMessagingInput(source: string): Promise<unknown> {
  const maximum = 1024 * 1024;
  if (source === "-") {
    return JSON.parse(await readStdinBounded(maximum)) as unknown;
  }
  if (!source.startsWith("@")) {
    throw new Error("messaging input must arrive through stdin or one checked private file");
  }
  const path = source.slice(1);
  const currentUid = process.getuid?.();
  if (currentUid === undefined) {
    throw new Error("messaging private-file ownership cannot be established");
  }
  const before = lstatSync(path, { bigint: true });
  if (
    !before.isFile()
    || before.uid !== BigInt(currentUid)
    || (before.mode & 0o077n) !== 0n
  ) {
    throw new Error("messaging input must be an owned regular file with no group or other access");
  }
  const text = readRegularFile(path, maximum, "messaging input file");
  const after = lstatSync(path, { bigint: true });
  if (
    !after.isFile()
    || after.uid !== before.uid
    || after.dev !== before.dev
    || after.ino !== before.ino
    || after.size !== before.size
    || after.mtimeNs !== before.mtimeNs
    || after.ctimeNs !== before.ctimeNs
    || after.mode !== before.mode
    || (after.mode & 0o077n) !== 0n
  ) throw new Error("messaging input file changed while it was being read");
  return JSON.parse(text) as unknown;
}

const MAX_THREAD_TEXT_BYTES = 64 * 1024;

async function readTextInput(source: string): Promise<string> {
  if (source === "-") return readStdinBounded(MAX_THREAD_TEXT_BYTES);
  if (source.startsWith("@")) {
    return readRegularFile(resolve(source.slice(1)), MAX_THREAD_TEXT_BYTES, "thread text file");
  }
  if (Buffer.byteLength(source, "utf8") > MAX_THREAD_TEXT_BYTES) {
    throw new Error(`inline thread text exceeds ${MAX_THREAD_TEXT_BYTES} bytes`);
  }
  return source;
}

const PLATFORM_POLICY_NOTICE = "Catalog entries are reviewed policy only. adapter-eligible does not mean an adapter or capability is installed.";

function selectedPlatformSurfaces(surfaceId?: PlatformSurfaceId): readonly PlatformSurfaceCatalogEntry[] {
  return surfaceId === undefined
    ? platformSurfaceIds.map((id) => socialPlatformCatalog[id])
    : [socialPlatformCatalog[surfaceId]];
}

function platformPolicyView(
  surfaceId?: PlatformSurfaceId,
): Record<string, unknown> {
  return {
    ok: true,
    kind: "reviewed-platform-policy",
    policyOnly: true,
    installationStatus: "not-evaluated",
    notice: PLATFORM_POLICY_NOTICE,
    installedCapabilitiesCommand: "ghostget capabilities [adapter]",
    surfaces: selectedPlatformSurfaces(surfaceId),
  };
}

function renderPlatformPolicyText(
  surfaceId?: PlatformSurfaceId,
): string {
  const lines = [
    "Ghostget reviewed platform policy",
    PLATFORM_POLICY_NOTICE,
    "Run 'ghostget capabilities [adapter]' to inspect installed capabilities.",
  ];
  for (const surface of selectedPlatformSurfaces(surfaceId)) {
    lines.push("", `${surface.displayName} (${surface.id})`, `  Exact origins: ${surface.originPolicy.exactOrigins.join(", ")}`);
    if (surface.originPolicy.additionalExactOrigins.state === "adapter-declared") {
      lines.push(`  Additional origin: ${surface.originPolicy.additionalExactOrigins.note}`);
    }
    for (const state of ["adapter-eligible", "unsupported", "not-applicable", "R4"] as const) {
      const operations = semanticOperationNames.flatMap((name) => {
        const policy = surface.operations[name];
        if (policy.state !== state) return [];
        return [policy.state === "adapter-eligible" ? `${name} (${policy.risk})` : name];
      });
      lines.push(`  ${state}: ${operations.length === 0 ? "none" : operations.join(", ")}`);
    }
    for (const name of compositionNames) {
      const composition = surface.compositions[name];
      if (composition === undefined) continue;
      const text = composition.text
        .map((field) => `${field.name}<=${field.safeMaxUnits} ${field.measurement}${field.required ? "" : " (optional)"}`)
        .join(", ");
      const attachment = composition.attachments.state === "none"
        ? "no attachments"
        : `${composition.attachments.minItems}-${composition.attachments.maxItems} ${composition.attachments.kinds.join("/")}`;
      lines.push(`  ${name} composition: ${text}; ${attachment}`);
    }
    lines.push(
      `  Long-form read/publish: ${surface.longForm.read.state}/${surface.longForm.publish.state}`,
      `  Thread read/publish: ${surface.threads.read.state}/${surface.threads.publish.state}`,
    );
  }
  return `${lines.join("\n")}\n`;
}

type RuntimeThreadPolicy = {
  readonly surface: PlatformSurfaceCatalogEntry;
  readonly maxWeightedLength: number;
  readonly maxItems: number;
  readonly measurement: keyof typeof textWeightPolicies;
  readonly operation: "threads.publish";
  readonly rootOperation: "posts.publish";
  readonly continuationOperation: "replies.create";
};

function runtimeThreadPolicy(surfaceId: PlatformSurfaceId): RuntimeThreadPolicy {
  const surface: PlatformSurfaceCatalogEntry = socialPlatformCatalog[surfaceId];
  const publishing = surface.threads.publish;
  if (publishing.state !== "adapter-eligible") {
    throw new Error(`${surfaceId} native thread publishing is ${publishing.state}; no thread split policy is available`);
  }
  const rootBody = surface.compositions.post?.text.find((field) => field.name === "body");
  const replyBody = surface.compositions.reply?.text.find((field) => field.name === "body");
  if (rootBody === undefined || replyBody === undefined || rootBody.measurement !== replyBody.measurement) {
    throw new Error(`${surfaceId} has an inconsistent reviewed thread composition policy`);
  }
  return {
    surface,
    maxWeightedLength: Math.min(rootBody.safeMaxUnits, replyBody.safeMaxUnits),
    maxItems: publishing.safeMaxItems,
    measurement: rootBody.measurement,
    operation: publishing.operation,
    rootOperation: publishing.rootOperation,
    continuationOperation: publishing.continuationOperation,
  };
}

async function runThreadSplit(
  arguments_: Extract<GhostgetArguments, { readonly command: "thread-split" }>,
  output: Output,
): Promise<number> {
  const { policy, text, weightPolicy, chunks } = await prepareThreadDraft(arguments_.surfaceId, arguments_.textSource);
  const view = {
    ok: true,
    kind: "local-thread-split",
    published: false,
    localSplitRequiresInstalledCapability: false,
    publicationInstallationStatus: "not-evaluated",
    notice: "This command only split local text. Publishing still requires a separately installed reviewed adapter capability.",
    surfaceId: arguments_.surfaceId,
    exactOrigins: policy.surface.originPolicy.exactOrigins,
    operation: policy.operation,
    rootOperation: policy.rootOperation,
    continuationOperation: policy.continuationOperation,
    measurement: policy.measurement,
    maxWeightedLength: policy.maxWeightedLength,
    maxItems: policy.maxItems,
    inputBytes: Buffer.byteLength(text, "utf8"),
    inputWeightedLength: weightedTextLength(text, weightPolicy),
    exactRoundTrip: true,
    chunks: chunks.map((chunk, index) => ({ index: index + 1, ...chunk })),
  };
  if (arguments_.json) {
    output.stdout(exactTerminalJson(view));
  } else {
    output.stdout(`Local ${safe(arguments_.surfaceId)} thread split: ${chunks.length} item(s); nothing was published.\n`);
    output.stdout("Publishing still requires a separately installed reviewed adapter capability.\n");
    output.stdout(`Each following chunk is an exact JSON string (${safe(policy.measurement)}, max ${policy.maxWeightedLength}).\n`);
    for (const [index, chunk] of chunks.entries()) {
      output.stdout(`${index + 1}/${chunks.length} · ${chunk.weightedLength}\n`);
      output.stdout(exactTerminalJson(chunk.text));
    }
  }
  return 0;
}

async function prepareThreadDraft(surfaceId: PlatformSurfaceId, textSource: string): Promise<{
  readonly policy: RuntimeThreadPolicy;
  readonly text: string;
  readonly weightPolicy: (typeof textWeightPolicies)[keyof typeof textWeightPolicies];
  readonly chunks: readonly { readonly text: string; readonly weightedLength: number }[];
}> {
  const policy = runtimeThreadPolicy(surfaceId);
  const text = await readTextInput(textSource);
  if (text.length === 0) throw new Error("thread text must not be empty");
  const weightPolicy = textWeightPolicies[policy.measurement];
  const result = splitWeightedThread(text, {
    maxWeightedLength: policy.maxWeightedLength,
    maxItems: policy.maxItems,
    weightPolicy,
  });
  if (!result.ok) {
    if (result.reason === "too-many-items") {
      throw new Error(`thread text requires more than the reviewed ${result.maxItems}-item limit for ${surfaceId}`);
    }
    if (result.reason === "unit-too-large") {
      throw new Error(`one Unicode grapheme or URL weighs ${result.unitWeight}, above the ${policy.maxWeightedLength}-unit per-item limit`);
    }
    if (result.reason === "invalid-unicode") throw new Error("thread text must contain well-formed Unicode");
    if (result.reason === "invalid-weight-policy") throw new Error(`invalid reviewed thread weight policy: ${result.issue}`);
    throw new Error("invalid reviewed thread split bounds");
  }
  const joined = result.chunks.map((chunk) => chunk.text).join("");
  if (joined !== text) throw new Error("thread splitter did not preserve the exact input");
  return { policy, text, weightPolicy, chunks: result.chunks };
}

async function runThreadPublish(
  arguments_: Extract<GhostgetArguments, { readonly command: "thread-publish" }>,
  environment: Readonly<Record<string, string | undefined>>,
  output: Output,
  registry: ProviderPluginRegistry = providerPluginRegistry,
): Promise<number> {
  const draft = await prepareThreadDraft(arguments_.surfaceId, arguments_.textSource);
  const invocation = prepareInvocation(
    arguments_.adapterId,
    draft.policy.operation,
    { items: draft.chunks.map((chunk) => chunk.text) },
    arguments_.authId,
    environment,
    registry,
  );
  if (invocation.manifest.surfaceId !== arguments_.surfaceId) {
    throw new Error(`adapter ${arguments_.adapterId} is not bound to ${arguments_.surfaceId}`);
  }
  const operation = invocation.manifest.operations[draft.policy.operation];
  if (operation?.risk !== "R3") throw new Error("reviewed thread publishing must be an R3 capability");
  const stored = createAndSaveInvocationPlan(
    invocation,
    environment,
    new Date(),
    registry,
  );
  printPreview(output, {
    ...previewView(stored, invocation, arguments_.headed),
    thread: {
      surfaceId: arguments_.surfaceId,
      items: draft.chunks.length,
      measurement: draft.policy.measurement,
      maxWeightedLength: draft.policy.maxWeightedLength,
      exactRoundTrip: draft.chunks.map((chunk) => chunk.text).join("") === draft.text,
    },
  }, arguments_.json);
  return arguments_.preview ? 0 : 4;
}

function manifestFromPlatform(adapterId: string, surfaceId: PlatformSurfaceId): ReturnType<typeof emptyManifest> {
  const surface = socialPlatformCatalog[surfaceId];
  const primaryOrigin = surface.originPolicy.exactOrigins[0];
  if (primaryOrigin === undefined) throw new Error(`${surfaceId} has no reviewed exact origin`);
  const browserDomains = [...new Set(surface.originPolicy.exactOrigins.map((origin) => new URL(origin).hostname.toLowerCase()))];
  const manifest = emptyManifest(adapterId, primaryOrigin, browserDomains, surfaceId);
  return {
    ...manifest,
    displayName: surface.displayName,
    origins: surface.originPolicy.exactOrigins,
    browserDomains,
  };
}

function installedOperationTransport(
  operation: GhostgetOperation,
): "provider-api" | "web-session-api" | "local-cli" | "reviewed-template-api" {
  if (isProviderOperation(operation)) return "provider-api";
  if (isWebSessionOperation(operation)) return "web-session-api";
  if (isReviewedTemplateOperation(operation)) return "reviewed-template-api";
  if (isLocalCliOperation(operation)) return "local-cli";
  throw new Error(DOM_ACTION_TRANSPORT_DISABLED_MESSAGE);
}

function capabilitySummary(
  environment: Readonly<Record<string, string | undefined>>,
  registry: ProviderPluginRegistry,
): readonly unknown[] {
  return listRuntimeManifests(environment, registry).map(({ id, result }) => result.ok
    ? {
        id,
        version: result.value.version,
        displayName: result.value.displayName,
        surfaceId: result.value.surfaceId ?? null,
        origins: result.value.origins,
        manifestHash: manifestHash(result.value),
        operations: Object.entries(result.value.operations).map(([operationId, operation]) => {
          const provider = isProviderOperation(operation)
            ? getProviderContract(operation.provider, registry)
            : null;
          const webSession = isWebSessionOperation(operation)
            ? getWebSessionContract(operation.webSession, registry)
            : null;
          const localCli = isLocalCliOperation(operation)
            ? getLocalCliContract(operation.localCli, registry)
            : null;
          const reviewedTemplate = isReviewedTemplateOperation(operation) ? operation.reviewedTemplate : null;
          return {
            id: operationId,
            description: operation.description,
            risk: operation.risk,
            sideEffect: operation.sideEffect,
            idempotency: operation.idempotency,
            dedupeWindowMs: operation.dedupeWindowMs,
            transport: installedOperationTransport(operation),
            input: operation.input,
            ...(provider === null ? {} : {
              provider: provider.provider,
              providerAction: provider.operation,
              providerContractVersion: provider.contractVersion,
              providerContractHash: providerContractHash(provider, registry),
              requiredScopeSets: provider.requiredScopeSets,
              coverage: provider.coverage,
              implementation: provider.implementation,
            }),
            ...(webSession === null ? {} : {
              site: webSession.site,
              webSessionAction: webSession.operation,
              webSessionContractVersion: webSession.contractVersion,
              webSessionContractHash: webSessionContractHash(
                webSession,
                registry,
              ),
              state: webSession.state,
              implementation: webSession.implementation,
            }),
            ...(localCli === null ? {} : {
              surface: localCli.surface,
              localCliAction: localCli.operation,
              localCliContractVersion: localCli.contractVersion,
              localCliContractHash: localCliContractHash(localCli, registry),
              localCliTool: localCli.tool,
              state: localCli.state,
              implementation: localCli.implementation,
            }),
            ...(reviewedTemplate === null ? {} : {
              state: reviewedTemplate.state,
              reviewedTemplateContractVersion: reviewedTemplate.contractVersion,
              reviewedTemplateContractHash: reviewedTemplateHash(reviewedTemplate),
              ...(reviewedTemplate.state === "capture-required"
                ? { instructions: reviewedTemplate.instructions }
                : {
                    reviewedAt: reviewedTemplate.reviewedAt,
                    evidenceSha256: reviewedTemplate.evidenceSha256,
                    origin: reviewedTemplate.template.origin,
                  }),
            }),
          };
        }),
      }
    : { id, invalid: true, issues: result.issues });
}

function oauthTokenListEntry(
  auth: Extract<GhostgetAuth, { readonly kind: "oauth-token-file" }>,
): { readonly expiresAt: string | null; readonly refreshable: boolean } {
  try {
    const credential = loadOAuthCredential(auth);
    return Object.freeze({
      expiresAt: credential.expiresAt,
      refreshable: credential.refresh !== null,
    });
  } catch {
    return Object.freeze({ expiresAt: null, refreshable: false });
  }
}

/** Whether a saved OAuth token can still be used, for the plain `auth list`. */
function oauthTokenState(
  auth: Extract<GhostgetAuth, { readonly kind: "oauth-token-file" }>,
  now: number,
): "ok" | "expired" | "unreadable" {
  try {
    const credential = loadOAuthCredential(auth);
    if (credential.refresh !== null || credential.expiresAt === null) return "ok";
    const expiresAt = Date.parse(credential.expiresAt);
    return Number.isFinite(expiresAt) && expiresAt <= now ? "expired" : "ok";
  } catch {
    return "unreadable";
  }
}

function listRuntimeManifests(
  environment: Readonly<Record<string, string | undefined>>,
  registry: ProviderPluginRegistry,
): ReturnType<typeof listInstalledManifests> {
  const stored = listInstalledManifests(environment, registry);
  const storedIds = new Set(stored.map((entry) => entry.id));
  const owned = registry.listOwnedManifests();
  const collision = owned.find((manifest) => storedIds.has(manifest.id));
  if (collision !== undefined) {
    throw new Error(
      `adapter ${collision.id} collides with an enabled portable provider plugin`,
    );
  }
  return Object.freeze([
    ...stored,
    ...owned.map((manifest) => Object.freeze({
      id: manifest.id,
      result: Object.freeze({ ok: true as const, value: manifest }),
    })),
  ].sort((left, right) => left.id.localeCompare(right.id)));
}

function officialProviderReadiness(
  environment: Readonly<Record<string, string | undefined>>,
  registry: ProviderPluginRegistry,
): readonly {
  readonly provider: string;
  readonly adapters: readonly string[];
  readonly auth: readonly { readonly id: string; readonly tokenReady: boolean; readonly usableOperations: number }[];
  readonly ready: boolean;
}[] {
  const manifests = listRuntimeManifests(environment, registry)
    .filter((entry) => entry.result.ok)
    .map((entry) => ({ id: entry.id, manifest: entry.result.ok ? entry.result.value : null }))
    .filter((entry): entry is { readonly id: string; readonly manifest: NonNullable<typeof entry.manifest> } => entry.manifest !== null);
  const auth = listAuth(environment).filter((entry) => entry.kind === "oauth-token-file");
  const bindings = registry.list().flatMap((plugin) =>
    plugin.bindings.filter((binding) => binding.transport === "provider-api"));
  return bindings.map((binding) => {
    const provider = binding.surfaceId;
    const adapters = manifests.filter((entry) => Object.values(entry.manifest.operations).some((operation) =>
      isProviderOperation(operation) && operation.provider.provider === provider));
    const operations = adapters.flatMap((entry) => Object.values(entry.manifest.operations)
      .filter(isProviderOperation)
      .filter((operation) => operation.provider.provider === provider)
      .flatMap((operation) => {
        const resolution = registry.resolveOperationDefinition(
          "provider-api",
          provider,
          operation.provider.action,
          operation.provider.contractVersion,
        );
        return resolution === undefined ? [] : [resolution.operation];
      }));
    const locators = auth.filter((entry) => entry.provider === provider).map((entry) => {
      let tokenReady = false;
      let tokenRefreshable = false;
      let usableOperations = 0;
      try {
        tokenRefreshable = loadOAuthCredential(entry).refresh !== null;
        loadOAuthToken(entry);
        tokenReady = true;
        usableOperations = operations.filter((operation) => {
          try {
            if (!("requiredScopeSets" in operation)) return false;
            requireOAuthScopes(entry, operation.requiredScopeSets);
            return true;
          } catch {
            return false;
          }
        }).length;
      } catch {
        // Doctor reports only readiness metadata and never token contents or paths.
      }
      return { id: entry.id, tokenReady, tokenRefreshable, usableOperations };
    });
    return {
      provider,
      adapters: adapters.map((entry) => entry.id),
      auth: locators,
      ready: adapters.length > 0 && locators.some((entry) => entry.tokenReady && entry.usableOperations > 0),
    };
  });
}

type WebSessionReadiness = {
  readonly site: string;
  readonly adapters: readonly string[];
  readonly observedOperations: readonly string[];
  readonly captureRequiredOperations: readonly string[];
  readonly accountBoundAuth: readonly string[];
  readonly ready: boolean;
};

function authenticatedWebSessionReadiness(
  environment: Readonly<Record<string, string | undefined>>,
  registry: ProviderPluginRegistry,
): readonly WebSessionReadiness[] {
  const manifests = listRuntimeManifests(environment, registry);
  const auth = listAuth(environment).filter((entry) =>
    isCookieCapableWebAuth(entry) || entry.kind === "linked-device-store"
  );
  const bindings = registry.list().flatMap((plugin) =>
    plugin.bindings.filter((binding) =>
      binding.transport === "web-session-api"
      || binding.transport === "linked-device"));
  return bindings.map((binding) => {
    const site = binding.surfaceId;
    const operations = manifests.flatMap((entry) => {
      if (!entry.result.ok || entry.result.value.schemaVersion !== 4) return [];
      return Object.entries(entry.result.value.operations).flatMap(([operationId, operation]) => {
        if (!isWebSessionOperation(operation) || operation.webSession.site !== site) return [];
        const contract = getWebSessionContract(operation.webSession, registry);
        return [{ adapter: entry.id, operation: operationId, state: contract.state }];
      });
    });
    const observed = operations.filter((entry) => entry.state === "observed");
    const captureRequired = operations.filter((entry) => entry.state === "capture-required");
    const accountBoundAuth = auth
      .filter((entry) => {
        try {
          requireProviderPluginAuth(binding, entry);
          return true;
        } catch {
          return false;
        }
      })
      .filter((entry) =>
        entry.subject !== undefined && binding.subject.matches(entry.subject))
      .map((entry) => entry.id)
      .sort();
    const adapters = [...new Set(observed.map((entry) => entry.adapter))].sort();
    const observedOperations = [...new Set(observed.map((entry) => entry.operation))].sort();
    const captureRequiredOperations = [...new Set(
      captureRequired.map((entry) => entry.operation),
    )].sort();
    return {
      site,
      adapters,
      observedOperations,
      captureRequiredOperations,
      accountBoundAuth,
      ready: adapters.length > 0 && accountBoundAuth.length > 0,
    };
  });
}

type LocalCliReadiness = {
  readonly surface: string;
  readonly adapters: readonly string[];
  readonly operations: readonly string[];
  readonly accountBoundAuth: readonly string[];
  readonly tool: LocalCliPluginBindingV1["tool"];
  readonly runtime: Awaited<ReturnType<LocalCliPluginBindingV1["inspect"]>>;
  readonly ready: boolean;
};

async function localCliReadiness(
  environment: Readonly<Record<string, string | undefined>>,
  registry: ProviderPluginRegistry,
): Promise<readonly LocalCliReadiness[]> {
  const manifests = listRuntimeManifests(environment, registry);
  const auth = listAuth(environment);
  const bindings = registry.list().flatMap((plugin) =>
    plugin.bindings.filter(
      (binding): binding is LocalCliPluginBindingV1 =>
        binding.transport === "local-cli",
    ));
  return Promise.all(bindings.map(async (binding) => {
    const installed = manifests.flatMap((entry) => {
      if (!entry.result.ok || entry.result.value.schemaVersion !== 6) return [];
      return Object.entries(entry.result.value.operations).flatMap(
        ([operationId, operation]) =>
          isLocalCliOperation(operation)
          && operation.localCli.surface === binding.surfaceId
            ? [{ adapter: entry.id, operation: operationId }]
            : [],
      );
    });
    const accountBoundAuth = auth.filter((entry) => {
      try {
        requireProviderPluginAuth(binding, entry);
        return entry.subject !== undefined
          && binding.subject.matches(entry.subject);
      } catch {
        return false;
      }
    }).map((entry) => entry.id).sort();
    let runtime: Awaited<ReturnType<LocalCliPluginBindingV1["inspect"]>>;
    try {
      runtime = await withLocalCliProviderCleanupAdmission(
        {
          registry,
          binding,
          auth: null,
          purpose: { kind: "inspect" },
          environment,
        },
        (registerCleanupBarrier) => binding.inspect(environment, {
          registerCleanupBarrier,
        }),
      );
    } catch {
      runtime = Object.freeze({
        ready: false,
        platform: process.platform,
        arch: process.arch,
        version: null,
        executableSha256: null,
        reason: "inspection-failed",
      });
    }
    const adapters = [...new Set(installed.map((entry) => entry.adapter))]
      .sort();
    const operations = [...new Set(installed.map((entry) => entry.operation))]
      .sort();
    return Object.freeze({
      surface: binding.surfaceId,
      adapters,
      operations,
      accountBoundAuth,
      tool: binding.tool,
      runtime,
      ready: runtime.ready
        && adapters.length > 0
        && accountBoundAuth.length > 0,
    });
  }));
}

function reviewedTemplateReservationStatus(
  environment: Readonly<Record<string, string | undefined>>,
  registry: ProviderPluginRegistry,
): {
  readonly mode: "derivation-reservation-only";
  readonly adapters: readonly string[];
  readonly operations: readonly string[];
  readonly executable: false;
  readonly requiredContract: "reviewed-template-v2-current-account-preflight";
} {
  const reservations = listRuntimeManifests(environment, registry).flatMap((entry) => {
    if (!entry.result.ok || entry.result.value.schemaVersion !== 5) return [];
    return Object.entries(entry.result.value.operations).flatMap(([operationId, operation]) =>
      isReviewedTemplateOperation(operation)
      && operation.reviewedTemplate.state === "capture-required"
        ? [{ adapter: entry.id, operation: operationId }]
        : []);
  });
  const adapters = [...new Set(reservations.map((entry) => entry.adapter))].sort();
  const operations = [...new Set(reservations.map((entry) => `${entry.adapter}/${entry.operation}`))].sort();
  return {
    mode: "derivation-reservation-only",
    adapters,
    operations,
    executable: false,
    requiredContract: "reviewed-template-v2-current-account-preflight",
  };
}

async function doctor(
  arguments_: Extract<GhostgetArguments, { readonly command: "doctor" }>,
  environment: Readonly<Record<string, string | undefined>>,
  output: Output,
  dependencies: GhostgetDependencies,
): Promise<number> {
  const registry = dependencies.providerPluginRegistry;
  const confirmationClaimRecovery =
    repairInterruptedConfirmationClaims(environment);
  const runJournalRecovery = repairInterruptedRunJournals(environment);
  const intentFences = inspectConfirmedWriteIntentFences(environment);
  const webSessionCleanupAdmissionRecovery =
    await recoverWebSessionCleanupAdmissions(environment);
  const linkedDeviceLifecycleAdmissionRecovery =
    recoverLinkedDeviceLifecycleAdmissions(environment);
  const linkedDeviceLifecycleRecovery =
    recoverLinkedDeviceLifecycleJournals({ environment });
  const linkedDeviceBindings = registry.list().flatMap((plugin) =>
    plugin.bindings.filter(
      (binding): binding is LinkedDevicePluginBindingV1 =>
        binding.transport === "linked-device"
        && binding.linkedDeviceLifecycle !== undefined,
    ));
  const [
    captureInspection,
    mediaInspection,
    linkedDeviceProtocols,
    localCliProviders,
  ] = await Promise.all([
    dependencies.inspectClipEnvironment(),
    dependencies.loadMediaRuntime().then(async (runtime) => ({
      runtime,
      report: await runtime.runDoctor({ env: environment }),
    })),
    Promise.all(linkedDeviceBindings.map(async (binding) => {
      try {
        return {
          surface: binding.surfaceId,
          ...(await binding.linkedDeviceLifecycle!.inspect(environment)),
        };
      } catch {
        return {
          surface: binding.surfaceId,
          ready: false,
          implementation: "unavailable",
          version: "unknown",
          integrity: "inspection-failed",
        };
      }
    })),
    localCliReadiness(environment, registry),
  ]);
  const capture = captureInspection.report;
  const media = mediaInspection.report;
  const portablePlugins = doctorPortableProviderPlugins(environment);
  const expiredPlansRemoved = purgeExpiredPlans(environment);
  const orphanedBrowserSnapshotsRemoved = purgeOrphanedBrowserSnapshots(environment);
  const adapters = capabilitySummary(environment, registry);
  const auth = listAuth(environment).map((entry) => ({ id: entry.id, kind: entry.kind }));
  const officialProviders = officialProviderReadiness(environment, registry);
  const derivations = listDerivations(environment);
  const unsettledRuns = listRunReceipts(environment).filter((receipt) =>
    "status" in receipt && (receipt.status === "pending" || receipt.status === "partial" || receipt.status === "indeterminate"));
  const browserCaptureBootstrapReady =
    captureInspection.browserCaptureBootstrapReady;
  const providerApiReady = officialProviders.some((provider) => provider.ready);
  const webSessionSites = authenticatedWebSessionReadiness(environment, registry);
  const webSessionApiReady = webSessionSites.some((site) => site.ready);
  const localCliReady = localCliProviders.some((provider) => provider.ready);
  const webSessionAdapters = [...new Set(webSessionSites.flatMap((site) => site.adapters))].sort();
  const reviewedTemplateReservations = reviewedTemplateReservationStatus(environment, registry);
  const reviewedTemplateApiReady = false;
  const actionReady = providerApiReady || webSessionApiReady || localCliReady;
  const runRecoveryHealthy = confirmationClaimRecovery.invalid === 0
    && runJournalRecovery.issues.length === 0
    && intentFences.issues.length === 0;
  const webSessionCleanupRecoveryHealthy =
    webSessionCleanupAdmissionRecovery.issues.length === 0;
  const linkedDeviceLifecycleRecoveryHealthy =
    linkedDeviceLifecycleRecovery.issues.length === 0
    && linkedDeviceLifecycleAdmissionRecovery.issues.length === 0;
  const recoveryHealthy = runRecoveryHealthy
    && webSessionCleanupRecoveryHealthy
    && linkedDeviceLifecycleRecoveryHealthy;
  const ghostgetReport = {
    home: ghostgetStateHome(environment),
    mediaArchiveReady: media.ok,
    installedAdapters: adapters.length,
    configuredAuth: auth,
    browserCaptureBootstrapReady,
    browserActionReady: false,
    providerApiReady,
    webSessionApiReady,
    webSessionAdapters,
    webSessionSites,
    localCliReady,
    localCliProviders,
    reviewedTemplateApiReady,
    reviewedTemplateReservations,
    officialProviders,
    linkedDeviceProtocols,
    // Compatibility field retained while callers move to the generic list.
    whatsappProtocol: linkedDeviceProtocols.find(
      (entry) => entry.surface === "whatsapp",
    ) ?? null,
    activeDerivations: derivations,
    unsettledRuns,
    confirmationClaimRecovery,
    runJournalRecovery,
    intentFences,
    webSessionCleanupAdmissionRecovery,
    linkedDeviceLifecycleRecovery,
    linkedDeviceLifecycleAdmissionRecovery,
    portablePlugins,
    mutationPolicy: "R2/R3 preview+digest confirmation; R4 blocked",
    rawHarRetention: "private-until-finish-or-discard",
    expiredPlansRemoved,
    orphanedBrowserSnapshotsRemoved,
  };
  const report = {
    ok: actionReady && recoveryHealthy && portablePlugins.ok,
    capture,
    media,
    ghostget: ghostgetReport,
    wrench: ghostgetReport,
    // Frozen doctor JSON compatibility aliases. Predecessor consumers received
    // this report under `wrench` and `oh`; all envelopes remain exact.
    oh: ghostgetReport,
  };
  if (arguments_.json) output.stdout(safeJson(report));
  else {
    output.stdout(sanitizeTerminalText(captureInspection.renderReport()));
    output.stdout("\nGhostget verified media archive\n");
    output.stdout(sanitizeTerminalText(mediaInspection.runtime.renderDoctorReport(media)));
    output.stdout("\nGhostget actions\n");
    output.stdout(`- Home: ${safe(report.ghostget.home)}\n`);
    output.stdout(`- Installed adapters: ${adapters.length}\n`);
    output.stdout(
      `- Portable plugins: ${portablePlugins.ok ? "healthy" : "attention required"}`
      + ` (${portablePlugins.installed} installed)\n`,
    );
    output.stdout(`- Auth locators: ${auth.length}\n`);
    output.stdout(
      `- Durable run recovery: ${runRecoveryHealthy ? "healthy" : "attention required"}`
      + ` (${runJournalRecovery.repaired} repaired, ${runJournalRecovery.issues.length} unresolved)\n`,
    );
    output.stdout(
      `- Intent fence readback: ${intentFences.issues.length === 0 ? "healthy" : "attention required"}`
      + ` (${intentFences.claims} claims, ${intentFences.issues.length} unresolved)\n`,
    );
    output.stdout(
      `- Provider resource cleanup recovery: ${webSessionCleanupRecoveryHealthy ? "healthy" : "attention required"}`
      + ` (${webSessionCleanupAdmissionRecovery.repaired} repaired, ${webSessionCleanupAdmissionRecovery.issues.length} unresolved)\n`,
    );
    output.stdout(
      `- Linked-device lifecycle recovery: ${linkedDeviceLifecycleRecoveryHealthy ? "healthy" : "attention required"}`
      + ` (${linkedDeviceLifecycleRecovery.repairedSafeRetry + linkedDeviceLifecycleRecovery.repairedIndeterminate + linkedDeviceLifecycleAdmissionRecovery.repaired} repaired, ${linkedDeviceLifecycleRecovery.issues.length + linkedDeviceLifecycleAdmissionRecovery.issues.length} unresolved)\n`,
    );
    output.stdout(`- Browser capture/bootstrap: ${browserCaptureBootstrapReady ? "ready" : "not ready"}\n`);
    output.stdout("- Generic browser/DOM action execution: disabled (internal API contracts only)\n");
    output.stdout(`- Official provider plugin APIs: ${providerApiReady ? "ready" : "not ready"}\n`);
    output.stdout(`- Authenticated internal APIs (any observed contract + account binding): ${webSessionApiReady ? "ready" : "not ready"}\n`);
    output.stdout(`- Local CLI providers: ${localCliReady ? "ready" : "not ready"}\n`);
    for (const readiness of localCliProviders) {
      output.stdout(
        `- ${safe(readiness.surface)} local CLI: ${readiness.ready ? "ready" : safe(readiness.runtime.reason ?? "not ready")}`
        + ` (${readiness.operations.length} operation${readiness.operations.length === 1 ? "" : "s"})\n`,
      );
    }
    for (const readiness of webSessionSites) {
      const state = readiness.ready
        ? "ready"
        : readiness.observedOperations.length > 0
          ? "account binding required"
          : readiness.captureRequiredOperations.length > 0
            ? "capture-required"
            : "not installed";
      output.stdout(
        `- ${safe(readiness.site)} authenticated internal API: ${state}`
        + ` (${readiness.observedOperations.length} observed, ${readiness.captureRequiredOperations.length} capture-required)\n`,
      );
    }
    for (const protocol of linkedDeviceProtocols) {
      output.stdout(
        `- ${safe(protocol.surface)} linked-device protocol ${safe(protocol.version)}: ${protocol.ready ? "ready" : "not installed"}\n`,
      );
      if (!protocol.ready && protocol.setupCommand !== undefined) {
        output.stdout(`  Setup: ${safe(protocol.setupCommand)}\n`);
      }
    }
    output.stdout(`- Generic internal-API derivation: reservation-only (schema-v5 templates are inert until account preflight)\n`);
    output.stdout(`- Generic internal-API execution: not available (reviewed-template v2 account preflight required)\n`);
    output.stdout(`- Active derivations: ${derivations.length}${derivations.length === 0 ? "" : " (run 'ghostget derive list')"}\n`);
    output.stdout(`- Unsettled runs: ${unsettledRuns.length}${unsettledRuns.length === 0 ? "" : " (run 'ghostget runs list')"}\n`);
    output.stdout(`- Writes: ${report.ghostget.mutationPolicy}\n`);
    output.stdout(`- Raw HAR retention: ${report.ghostget.rawHarRetention}\n`);
  }
  return report.ok ? 0 : 3;
}

function confirmationContractView(plan: ReturnType<typeof createInvocationPlan>["plan"]): Record<string, unknown> {
  if (plan.transport === "portable-provider-plugin") {
    const identity = plan.portablePluginContract;
    return {
      transport: plan.transport,
      identity: `${identity.pluginId}/${identity.adapterId}/${identity.operation}@${identity.contractVersion}`,
      pluginId: identity.pluginId,
      pluginVersion: identity.pluginVersion,
      hostApiVersion: identity.hostApiVersion,
      bundleSha256: identity.bundleSha256,
      manifestSha256: identity.manifestSha256,
      adapterId: identity.adapterId,
      pluginTransport: identity.transport,
      surfaceId: identity.surfaceId,
      operation: identity.operation,
      version: identity.contractVersion,
      descriptorSha256: identity.descriptorSha256,
    };
  }
  if (plan.transport === "provider-api") {
    return {
      transport: plan.transport,
      identity: `${plan.providerContract.provider}/${plan.providerContract.action}@${plan.providerContract.version}`,
      provider: plan.providerContract.provider,
      action: plan.providerContract.action,
      version: plan.providerContract.version,
      hash: plan.providerContract.hash,
    };
  }
  if (plan.transport === "web-session-api") {
    return {
      transport: plan.transport,
      identity: `${plan.webSessionContract.site}/${plan.webSessionContract.action}@${plan.webSessionContract.version}`,
      site: plan.webSessionContract.site,
      action: plan.webSessionContract.action,
      version: plan.webSessionContract.version,
      hash: plan.webSessionContract.hash,
    };
  }
  if (plan.transport === "local-cli") {
    return {
      transport: plan.transport,
      identity: `${plan.localCliContract.surface}/${plan.localCliContract.action}@${plan.localCliContract.version}`,
      surface: plan.localCliContract.surface,
      action: plan.localCliContract.action,
      version: plan.localCliContract.version,
      hash: plan.localCliContract.hash,
      tool: plan.localCliContract.tool,
    };
  }
  if (plan.transport === "reviewed-template-api") {
    return {
      transport: plan.transport,
      identity: `${plan.adapter.id}/${plan.operation}@${plan.reviewedTemplateContract.version}`,
      version: plan.reviewedTemplateContract.version,
      hash: plan.reviewedTemplateContract.hash,
    };
  }
  throw new Error(DOM_ACTION_TRANSPORT_DISABLED_MESSAGE);
}

function identityBindingView(
  operation: GhostgetOperation,
  input: OperationInput,
  auth: InvocationAuthority,
): Record<string, unknown> {
  const subject = auth.subject ?? null;
  if (isPublicWebSessionInvocationAuthority(auth)) {
    return {
      status: "public",
      subject,
      accountActor: null,
      requestedActor: null,
    };
  }
  const requestedActor = isProviderOperation(operation) && (operation.risk === "R2" || operation.risk === "R3")
    ? typeof input.actor === "string"
      ? input.actor
      : typeof input.author === "string" ? input.author : null
    : null;
  const accountActor = (
    requestedActor === null
    && (isProviderOperation(operation) || isWebSessionOperation(operation))
  ) ? subject : null;
  const status = requestedActor !== null
    ? requestedActor === subject ? "subject-match" : "contract-preflight-required"
    : accountActor !== null ? "account-subject" : subject !== null ? "subject-only" : "unbound";
  return {
    status,
    subject,
    accountActor,
    requestedActor,
  };
}

function previewView(
  stored: ReturnType<typeof createInvocationPlan>,
  invocation: ReturnType<typeof prepareInvocation>,
  headed: boolean,
): Record<string, unknown> {
  if (
    invocation.manifest.id !== stored.plan.adapter.id
    || invocation.manifest.version !== stored.plan.adapter.version
    || invocation.operationId !== stored.plan.operation
    || invocation.auth.id !== stored.plan.auth.id
    || invocation.auth.kind !== stored.plan.auth.kind
    || !canonicalJsonSha256Matches(stored.plan.auth.hash, invocation.auth)
  ) throw new Error("prepared invocation no longer matches its confirmation plan");
  const operation = invocation.manifest.operations[invocation.operationId];
  if (operation === undefined) throw new Error("operation disappeared while previewing its confirmation plan");
  const previewInputValue = (value: unknown): unknown => isPlanBoundFile(value)
    ? summarizePlanFile(value)
    : Array.isArray(value) ? value.map(previewInputValue) : value;
  const input = Object.fromEntries(Object.entries(stored.plan.input).map(([key, value]) => [key, previewInputValue(value)]));
  return {
    ok: true,
    status: "confirmation-required",
    digest: stored.digest,
    expiresAt: stored.plan.expiresAt,
    adapter: stored.plan.adapter,
    operation: stored.plan.operation,
    risk: stored.plan.risk,
    sideEffect: stored.plan.sideEffect,
    input,
    inputHash: stored.plan.inputHash,
    dispatches: stored.plan.dispatches,
    auth: {
      id: stored.plan.auth.id,
      kind: stored.plan.auth.kind,
      realmFingerprint: stored.plan.auth.hash.slice(0, 16),
    },
    identityBinding: identityBindingView(operation, stored.plan.input, invocation.auth),
    transport: stored.plan.transport,
    contract: confirmationContractView(stored.plan),
    ...(stored.plan.duplicateRisk === undefined
      ? {}
      : {
          duplicateRisk: {
            sourceRunId: stored.plan.duplicateRisk.sourceRunId,
            successorIntentFingerprint:
              stored.plan.duplicateRisk.intentHash.slice(0, 16),
            warning:
              "The source post may already exist. Confirming creates one distinct at-most-once successor intent and can publish a duplicate; the source evidence remains preserved.",
          },
        }),
    confirmCommand: `ghostget confirm ${stored.digest}${headed ? " --headed" : ""}`,
  };
}

function directPreviewView(invocation: ReturnType<typeof prepareInvocation>): Record<string, unknown> {
  const operation = invocation.manifest.operations[invocation.operationId];
  if (operation === undefined) throw new Error("operation disappeared while previewing it");
  return {
    ok: true,
    status: "preview",
    requiresConfirmation: false,
    adapter: {
      id: invocation.manifest.id,
      version: invocation.manifest.version,
      hash: manifestHash(invocation.manifest),
    },
    operation: invocation.operationId,
    risk: operation.risk,
    sideEffect: operation.sideEffect,
    input: invocation.input,
    auth: {
      id: invocation.auth.id,
      kind: invocation.auth.kind,
      realmFingerprint: sha256(canonicalJson(invocation.auth)).slice(0, 16),
    },
    identityBinding: identityBindingView(operation, invocation.input, invocation.auth),
    transport: invocation.portablePluginContract === undefined
      ? installedOperationTransport(operation)
      : "portable-provider-plugin",
    ...(invocation.portablePluginContract === undefined
      ? {}
      : {
          portablePluginContract: invocation.portablePluginContract,
        }),
  };
}

export function invocationView(result: Awaited<ReturnType<typeof executeReadInvocation>>): Record<string, unknown> {
  const readFailure = result.receipt.risk === "R1"
    && result.receipt.status === "failed"
    ? result.readFailure ?? readFailureProjection("contract-drift")
    : undefined;
  return {
    ok: result.receipt.status === "succeeded" || result.receipt.status === "submitted",
    status: result.receipt.status,
    runId: result.receipt.runId,
    replayed: result.replayed,
    receipt: result.receipt,
    output: result.output,
    ...(readFailure === undefined ? {} : { readFailure }),
  };
}

export function cachedInvocationView(
  result: ReadProjectionCacheResult,
): Record<string, unknown> {
  if (result.status === "miss") {
    return {
      ok: false,
      status: "cache-miss",
      source: "cache",
      projection: { key: result.key },
    };
  }
  return {
    ok: true,
    status: "cached",
    source: "cache",
    projection: {
      key: result.key,
      dataRevision: result.dataRevision,
      createdAt: result.createdAt,
      dataChangedAt: result.dataChangedAt,
      validatedAt: result.validatedAt,
      runId: result.runId,
      ageMs: result.ageMs,
      freshness: result.freshness,
    },
    output: result.output,
  };
}

export function revalidatedInvocationView(
  result: RevalidatedCapability,
): Record<string, unknown> {
  return {
    ...invocationView(result.live),
    source: "live",
    cache: result.cache,
  };
}

function printPreview(output: Output, value: Record<string, unknown>, json: boolean): void {
  output.stdout(json ? exactTerminalJson(value) : exactTerminalJson(value));
}

/** Records a bounded repair lead and returns its inspect id, or null when no
 * usable lead was stored. Human mode prints the hint on stderr; `--json` keeps
 * stderr clean and the caller folds the id into the error envelope's `next`. */
function reportContractRepairLead(
  createSignal: () => ContractRepairSignal,
  environment: Readonly<Record<string, string | undefined>>,
  output: Output,
  json = false,
): string | null {
  if (environment.GHOSTGET_REPAIR_SIGNALS === "off") return null;
  try {
    const signal = createSignal();
    const status = cacheContractRepairSignal(signal, environment);
    if (status !== "stored" && status !== "duplicate") {
      if (!json) output.stderr(`ghostget: repair diagnostics ${status}; the original operation outcome is unchanged.\n`);
      return null;
    }
    if (!json) {
      output.stderr(`ghostget: repair lead only; do not retry automatically. Inspect: ghostget contracts repair --id ${signal.id} --json\n`);
    }
    return signal.id;
  } catch {
    if (!json) output.stderr("ghostget: repair diagnostics unavailable; the original operation outcome is unchanged.\n");
    return null;
  }
}

async function runCommand(
  arguments_: GhostgetArguments,
  environment: Readonly<Record<string, string | undefined>>,
  output: Output,
  dependencies: GhostgetDependencies,
  signal?: AbortSignal,
  onUsefulResult?: () => void,
): Promise<number> {
  if (arguments_.command === "help") {
    output.stdout(renderGhostgetUsage());
    return 0;
  }
  if (arguments_.command === "login") {
    const result = await runAccountsDeviceLogin(
      environment,
      {
        onUserCode: (userCode, verificationUri) => {
          output.stderr(
            `Open ${safe(verificationUri)} in a browser where you are already signed in to Hraness Accounts and enter code: ${safe(userCode)}\n`,
          );
        },
        onPending: () => {
          output.stderr("Waiting for browser approval...\n");
        },
        onSlowDown: () => {
          output.stderr("Polling more slowly...\n");
        },
      },
      undefined,
      signal,
    );
    if (arguments_.json) {
      output.stdout(exactTerminalJson({ ok: result.kind === "success", ...result }));
    } else if (result.kind === "success") {
      output.stdout(`${safe(result.message)}\n`);
    } else if (result.kind === "denied") {
      output.stderr("Login was denied in the browser.\n");
    } else if (result.kind === "expired") {
      output.stderr("The sign-in code expired. Run 'ghostget login' again.\n");
    } else {
      output.stderr(`Login failed: ${safe(result.message)}\n`);
    }
    return result.kind === "success" ? 0 : 3;
  }
  if (arguments_.command === "logout") {
    await runAccountsSignOut(environment);
    const message = "Signed out of Hraness Accounts.";
    if (arguments_.json) {
      output.stdout(exactTerminalJson({ ok: true, message }));
    } else {
      output.stdout(`${message}\n`);
    }
    return 0;
  }
  if (arguments_.command === "whatsapp-automation-install") {
    const { installReviewedWhatsAppAutomationBinary } = await import("./providers/whatsapp-automation-runtime");
    const installed = arguments_.binary === undefined
      ? await (await import("./providers/messaging-native-install")).installBundledMessagingRuntime("whatsapp", environment)
      : await installReviewedWhatsAppAutomationBinary(arguments_.binary, environment);
    print(output, { ok: true, installed: true, ...installed }, arguments_.json);
    return 0;
  }
  if (arguments_.command === "messaging-automation-serve") {
    const runtime = await import("./messaging-automation-server");
    await runtime.serveMessagingAutomationStdio({ input: process.stdin, output: process.stdout, environment, registry: dependencies.providerPluginRegistry, ...(signal ? { signal } : {}) });
    return 0;
  }
  if (arguments_.command === "imessage-transport-install") {
    const runtime = await dependencies.loadImsgDirectInstallRuntime();
    const installed = arguments_.binary === undefined
      ? await (await import("./providers/messaging-native-install")).installBundledMessagingRuntime("imessage", environment).then(result => ({ ...result, executableSha256: result.sha256, alreadyPresent: result.alreadyPresent === true }))
      : await runtime.installReviewedImsgBinary(arguments_.binary, environment);
    const result = Object.freeze({
      ok: true,
      installed: true,
      alreadyPresent: installed.alreadyPresent,
      tool: "imsg-private-transport",
      version: installed.version,
      executableSha256: installed.executableSha256,
    });
    print(output, result, arguments_.json);
    return 0;
  }
  if (arguments_.command === "messaging-reconcile") {
    const claimRecovery = repairInterruptedConfirmationClaims(environment);
    if (claimRecovery.invalid > 0) {
      throw new Error(
        "local messaging recovery has unresolved state; run ghostget doctor before reconciliation",
      );
    }
    const result = reconcileMessagingRunInternal(arguments_.runId, {
      environment,
    });
    print(output, result, arguments_.json);
    return result.state === "indeterminate"
      ? 5
      : result.state === "submitted"
        ? 0
        : 3;
  }
  if (arguments_.command === "clip") {
    return runCaptureCommand(
      [],
      arguments_.arguments,
      environment,
      output,
      dependencies,
      signal,
      onUsefulResult,
    );
  }
  if (arguments_.command === "read") {
    return runCaptureCommand(
      ["inspect"],
      arguments_.arguments,
      environment,
      output,
      dependencies,
      signal,
      onUsefulResult,
    );
  }
  if (arguments_.command === "media") {
    const media = await dependencies.loadMediaRuntime();
    return media.runCli(arguments_.arguments, {
      io: output,
      ...(onUsefulResult === undefined ? {} : { onUsefulResult }),
      environment,
      ...(signal === undefined ? {} : { signal }),
    });
  }
  if (arguments_.command === "apple-photos-export-contact-evidence") {
    const runtime = await dependencies.loadApplePhotosCliRuntime();
    const result = await runtime.exportApplePhotosContactEvidenceForCli({
      ...(arguments_.library === undefined
        ? {}
        : { library: arguments_.library }),
      environment,
      progress: (event) => {
        output.stderr(runtime.formatApplePhotosContactEvidenceProgress(event));
      },
      ...(signal === undefined ? {} : { signal }),
    });
    output.stdout(
      runtime.encodeApplePhotosContactEvidenceCliOutput(result, arguments_.json),
    );
    onUsefulResult?.();
    return 0;
  }
  if (arguments_.command === "whatsapp-export-message-like-me") {
    const admission = acquireReadProjectionAuthAdmission(
      arguments_.authId,
      environment,
    );
    try {
      const auth = loadAuth(arguments_.authId, environment);
      if (auth.kind !== "linked-device-store" || auth.provider !== "whatsapp") {
        throw new Error(
          "Message Like Me export requires a WhatsApp linked-device-store auth locator",
        );
      }
      const runtime = await dependencies.loadWhatsAppMessageLikeMeCliRuntime();
      const result = await runtime.exportWhatsAppMessageLikeMeFromAuth({
        auth,
        outputRoot: arguments_.output,
        environment,
        onProgress: (progress) => {
          output.stderr(renderWhatsAppMessageLikeMeProgress(progress));
        },
        ...(signal === undefined ? {} : { signal }),
      });
      if (arguments_.json) {
        output.stdout(runtime.encodeWhatsAppMessageLikeMeCliResult(result));
      } else {
        output.stdout(`WhatsApp Message Like Me bundle: ${safe(result.bundle.outputRoot)}\n`);
        output.stdout(`Manifest SHA-256: ${safe(result.bundle.manifestSha256)}\n`);
        output.stdout("Remote history completeness is not claimed. No cloud sync occurred.\n");
      }
      onUsefulResult?.();
      return 0;
    } finally {
      admission.release();
    }
  }
  if (arguments_.command === "beeper-export-contact-interactions") {
    const runtime = await dependencies.loadBeeperContactInteractionCliRuntime();
    runtime.assertBeeperContactInteractionExportRuntime();
    const admission = acquireReadProjectionAuthAdmission(
      arguments_.authId,
      environment,
    );
    try {
      const auth = loadAuth(arguments_.authId, environment);
      if (auth.kind !== "linked-device-store" || auth.provider !== "beeper") {
        throw new Error(
          "Beeper contact interaction export requires a Beeper linked-device-store auth locator",
        );
      }
      const result = await runtime.exportBeeperContactInteractionsFromAuth({
        auth,
        limits: {
          ...(arguments_.limitChats === undefined
            ? {}
            : { limitChats: arguments_.limitChats }),
          ...(arguments_.limitMessages === undefined
            ? {}
            : { limitMessages: arguments_.limitMessages }),
          ...(arguments_.maxParticipants === undefined
            ? {}
            : { maxParticipants: arguments_.maxParticipants }),
        },
        environment,
        onProgress: (progress) => {
          output.stderr(renderBeeperMessageLikeMeProgress(progress));
        },
        ...(signal === undefined ? {} : { signal }),
      });
      output.stdout(runtime.encodeBeeperContactInteractionExportResult(result));
      onUsefulResult?.();
      return 0;
    } finally {
      admission.release();
    }
  }
  if (arguments_.command === "beeper-export-message-like-me") {
    const admission = acquireReadProjectionAuthAdmission(
      arguments_.authId,
      environment,
    );
    try {
      const auth = loadAuth(arguments_.authId, environment);
      if (auth.kind !== "linked-device-store" || auth.provider !== "beeper") {
        throw new Error(
          "Message Like Me export requires a Beeper linked-device-store auth locator",
        );
      }
      const runtime = await dependencies.loadBeeperMessageLikeMeCliRuntime();
      const result = await runtime.exportBeeperMessageLikeMeFromAuth({
        auth,
        outputRoot: arguments_.output,
        limits: {
          ...(arguments_.limitChats === undefined
            ? {}
            : { limitChats: arguments_.limitChats }),
          ...(arguments_.limitMessages === undefined
            ? {}
            : { limitMessages: arguments_.limitMessages }),
          ...(arguments_.maxParticipants === undefined
            ? {}
            : { maxParticipants: arguments_.maxParticipants }),
        },
        environment,
        onProgress: (progress) => {
          output.stderr(renderBeeperMessageLikeMeProgress(progress));
        },
        ...(signal === undefined ? {} : { signal }),
      });
      const summary = Object.freeze({
        ok: true,
        outputRoot: result.outputRoot,
        manifestPath: result.manifestPath,
        manifestSha256: result.manifestSha256,
        completeness: result.manifest.completeness,
        warnings: result.manifest.warnings,
        counts: result.manifest.counts,
      });
      print(output, summary, arguments_.json);
      onUsefulResult?.();
      return 0;
    } finally {
      admission.release();
    }
  }
  if (
    arguments_.command === "messaging-routes"
    || arguments_.command === "messaging-resolve"
    || arguments_.command === "messaging-context"
    || arguments_.command === "messaging-preview"
  ) {
    const privateOutput = validateMessagingPrivateOutputPath(
      arguments_.privateOutput,
      environment,
    );
    const request = await readMessagingInput(arguments_.inputSource);
    const options = {
      environment,
      registry: dependencies.providerPluginRegistry,
      ...(signal === undefined ? {} : { signal }),
    } as const;
    const artifact = arguments_.command === "messaging-routes"
      ? await discoverMessagingRoutesInternal(request, options)
      : arguments_.command === "messaging-resolve"
        ? await resolveMessagingRouteInternal(request, options)
        : arguments_.command === "messaging-context"
          ? await readMessagingContextInternal(request, options)
          : await previewMessagingTurnInternal(request, options);
    const receipt = writeMessagingPrivateOutput(
      privateOutput,
      artifact,
      environment,
    );
    output.stdout(exactTerminalJson(receipt));
    if (arguments_.command === "messaging-context") onUsefulResult?.();
    return 0;
  }
  if (arguments_.command === "doctor") {
    return doctor(arguments_, environment, output, dependencies);
  }
  if (arguments_.command === "capabilities") {
    return runCapabilities(
      arguments_,
      environment,
      output,
      dependencies.providerPluginRegistry,
    );
  }
  if (arguments_.command === "contracts-catalog") {
    return runContractsCatalog(
      arguments_,
      environment,
      output,
      dependencies.providerPluginRegistry,
    );
  }
  if (arguments_.command === "contracts-check") {
    return await runContractsCheck(
      arguments_,
      environment,
      output,
      dependencies.providerPluginRegistry,
      { readStdin: readStdinBounded },
    );
  }
  if (arguments_.command === "contracts-schema") {
    return runContractsSchema(arguments_, output);
  }
  if (arguments_.command === "contracts-repair") {
    return await runContractsRepair(arguments_, environment, output, dependencies.providerPluginRegistry, { readStdin: readStdinBounded });
  }
  if (arguments_.command === "plugin-list") {
    return await runPluginList(
      arguments_,
      environment,
      output,
      dependencies.providerPluginRegistry,
    );
  }
  if (arguments_.command === "plugin-show") {
    return await runPluginShow(
      arguments_,
      environment,
      output,
      dependencies.providerPluginRegistry,
    );
  }
  if (arguments_.command === "browsers") {
    const { json, text } = browserProfilesResult(environment);
    if (arguments_.json) output.stdout(safeJson(json));
    else output.stdout(sanitizeTerminalText(redactSensitiveText(text)));
    return 0;
  }
  if (arguments_.command === "platforms") {
    if (arguments_.json) {
      output.stdout(safeJson(platformPolicyView(arguments_.surfaceId)));
    } else {
      output.stdout(
        sanitizeTerminalText(
          redactSensitiveText(renderPlatformPolicyText(arguments_.surfaceId)),
        ),
      );
    }
    return 0;
  }
  if (arguments_.command === "thread-split") {
    const code = await runThreadSplit(arguments_, output);
    if (code === 0) onUsefulResult?.();
    return code;
  }
  if (arguments_.command === "thread-publish") {
    return runThreadPublish(
      arguments_,
      environment,
      output,
      dependencies.providerPluginRegistry,
    );
  }
  if (arguments_.command === "auth-login") {
    const login = await loginGoogleOAuth({
      clientFile: resolve(arguments_.clientFile),
      openBrowser: arguments_.openBrowser,
      onAuthorizationUrl: (url) => {
        output.stderr(
          `Approve Google access in your system browser. If it did not open, use this one-time URL:\n${safe(url)}\n`,
        );
      },
      ...(signal === undefined ? {} : { signal }),
    });
    const installed = installManagedGoogleOAuth(
      arguments_.id,
      login,
      environment,
      arguments_.force ? { force: true } : {},
    );
    const result = {
      ok: true,
      id: installed.auth.id,
      provider: installed.auth.provider,
      subject: installed.auth.subject,
      scopes: installed.auth.scopes,
      renewal: "automatic",
      refreshExpiresAt: login.refreshTokenExpiresAt,
    } as const;
    // This bounded view contains intentionally exposed, validated auth metadata
    // and no credential or token-file fields. Keep its public scope identifiers
    // exact instead of passing them through the generic URL credential redactor.
    if (arguments_.json) output.stdout(exactTerminalJson(result));
    else {
      output.stdout(
        `Connected ${safe(login.subject)} as ${safe(arguments_.id)}. Ghostget will renew Google access automatically.\n`,
      );
    }
    if (login.refreshTokenExpiresAt !== null) {
      output.stderr(
        `Google made this refresh credential time-limited until ${safe(login.refreshTokenExpiresAt)}. Publish the personal OAuth app to production and repeat with --force for durable renewal.\n`,
      );
    }
    return 0;
  }
  if (arguments_.command === "auth-list") {
    const values = listAuth(environment).map((auth) => ({
      id: auth.id,
      kind: auth.kind,
      realmFingerprint: sha256(canonicalJson(auth)).slice(0, 16),
      subject: auth.subject ?? null,
      ...(auth.kind === "cookie-source" ? { source: auth.source, profile: auth.profile ?? null, displayName: auth.displayName ?? null } : {}),
      ...(auth.kind === "browser-profile" ? {
        trustUnfilteredEgress: true,
        ...(auth.cookieSource === undefined ? {} : { cookieSource: auth.cookieSource }),
        ...(auth.cookieProfile === undefined ? {} : { cookieProfile: auth.cookieProfile }),
      } : {}),
      ...(auth.kind === "oauth-token-file" ? {
        provider: auth.provider,
        scopes: auth.scopes,
        managed: auth.managed === true,
        token: oauthTokenListEntry(auth),
      } : {}),
      ...(auth.kind === "linked-device-store" ? {
        provider: auth.provider,
      } : {}),
    }));
    if (arguments_.json) output.stdout(exactTerminalJson({ ok: true, auth: values }));
    else if (outputAudience(environment, output) === "agent") print(output, values, false);
    else {
      writeAuthLines(
        authListText(
          listAuth(environment).map((auth) => auth.kind === "oauth-token-file"
            ? { ...authSummary(auth), token: oauthTokenState(auth, Date.now()), managed: auth.managed === true }
            : authSummary(auth)),
          outputStyle(environment, output),
        ),
        outputAudience(environment, output),
        output,
      );
    }
    return 0;
  }
  if (arguments_.command === "auth-bind") {
    const authSnapshot = loadAuthSnapshot(arguments_.id, environment);
    const auth = authSnapshot.auth;
    const binding = dependencies.providerPluginRegistry.requireAccountRoute(
      arguments_.site,
    );
    requireProviderPluginAuth(binding, auth);
    const portableIdentity =
      portableProviderPluginSubjectProbeIdentity(binding);
    const lease = portableIdentity === null
      ? null
      : acquirePortableProviderPluginInvocationLease(
          portableIdentity,
          crypto.randomUUID(),
          environment,
        );
    const containment = lease === null
      ? null
      : createPortableProviderPluginInvocationLeaseContainmentController(
          lease,
          environment,
        );
    try {
      const probed = await dependencies.probePluginSubject(
        binding,
        auth,
        signal,
        dependencies.providerPluginRegistry,
        environment,
      );
      const identity = typeof probed === "string"
        ? { subject: probed, displayName: null }
        : probed;
      const subject = identity.subject;
      if (!binding.subject.matches(subject)) {
        throw new Error(
          `provider plugin surface ${binding.surfaceId} returned a subject outside ${binding.subject.format}`,
        );
      }
      if (
        auth.subject !== undefined
        && auth.subject !== subject
        && !arguments_.force
      ) {
        throw new Error("auth locator is already bound to a different account; repeat with --force only after reviewing the active signed-in account");
      }
      // The handle is display-only: one the auth contract cannot carry is
      // dropped rather than failing the bind.
      let displayName: string | undefined;
      if (identity.displayName !== null) {
        try {
          displayName = normalizeAuthDisplayName(identity.displayName);
        } catch {
          displayName = undefined;
        }
      }
      const bound = auth.kind === "cookie-source" && displayName !== undefined
        ? { ...auth, subject, displayName }
        : { ...auth, subject };
      await dependencies.beforeAuthBindCommit();
      if (!replaceAuthIfUnchanged(
        authSnapshot,
        bound,
        environment,
      ).replaced) {
        throw new Error(
          `auth locator ${auth.id} changed while its account was being probed; the concurrent value was preserved`,
        );
      }
      const boundAudience = outputAudience(environment, output);
      if (arguments_.json || boundAudience === "agent") {
        print(output, {
          ok: true,
          id: bound.id,
          site: arguments_.site,
          subject: bound.subject,
          ...(displayName === undefined ? {} : { displayName }),
          realmFingerprint: sha256(canonicalJson(bound)).slice(0, 16),
        }, true);
      } else {
        writeAuthLines(
          authBoundLines({ id: safe(bound.id), site: arguments_.site, subject: safe(subject), ...(displayName === undefined ? {} : { displayName: safe(displayName) }) }, outputStyle(environment, output)),
          boundAudience,
          output,
        );
      }
      return 0;
    } finally {
      if (containment !== null) {
        containment.cleanupComplete();
        releasePortableProviderPluginInvocationLease(
          containment.current,
          environment,
        );
      }
    }
  }
  if (arguments_.command === "auth-pair") {
    const auth = loadAuth(arguments_.id, environment);
    if (auth.kind !== "linked-device-store") {
      throw new Error("auth pair requires a linked-device-store locator");
    }
    const binding = dependencies.providerPluginRegistry.requireSessionRoute(
      auth.provider,
    );
    if (binding.transport !== "linked-device") {
      throw new Error(
        `provider plugin surface ${auth.provider} is not a linked-device transport`,
      );
    }
    requireProviderPluginAuth(binding, auth);
    if (binding.linkedDeviceLifecycle === undefined) {
      throw new Error(
        `provider plugin surface ${auth.provider} does not declare pairing`,
      );
    }
    output.stdout(
      `Starting explicit ${safe(auth.provider)} linked-device pairing. This creates a separate device session and performs a bounded bootstrap sync; it does not reuse browser cookies.\n`,
    );
    const paired = await runLinkedDevicePairLifecycle(
      binding,
      auth.id,
      {
        registry: dependencies.providerPluginRegistry,
        environment,
        ...(arguments_.phone === undefined
          ? {}
          : { phone: arguments_.phone }),
        ...(signal === undefined ? {} : { signal }),
        invokePair: dependencies.pairLinkedDeviceAuth,
      },
    );
    output.stdout(
      `Paired and bound ${safe(auth.id)} to ${safe(paired.subject)}. Use 'ghostget auth sync ${safe(auth.id)} --once' when you explicitly want to refresh its local projection.\n`,
    );
    return 0;
  }
  if (arguments_.command === "auth-sync") {
    const auth = loadAuth(arguments_.id, environment);
    if (
      auth.kind !== "linked-device-store"
      || auth.subject === undefined
    ) {
      throw new Error(
        "auth sync requires a paired and account-bound linked-device-store locator",
      );
    }
    const binding = dependencies.providerPluginRegistry.requireSessionRoute(
      auth.provider,
    );
    if (
      binding.transport !== "linked-device"
      || binding.linkedDeviceLifecycle === undefined
    ) {
      throw new Error(
        `provider plugin surface ${auth.provider} does not declare one-shot linked-device sync`,
      );
    }
    requireProviderPluginAuth(binding, auth);
    if (!binding.subject.matches(auth.subject)) {
      throw new Error(
        `auth subject does not match ${binding.subject.format}`,
      );
    }
    output.stderr(
      `${auth.provider} sync explicitly connects the linked device and may emit protocol transport acknowledgements according to its registered lifecycle contract.\n`,
    );
    const lifecycle = await runLinkedDeviceSyncOnceLifecycle(
      binding,
      auth.id,
      {
        registry: dependencies.providerPluginRegistry,
        environment,
        ...(signal === undefined ? {} : { signal }),
        invokeSyncOnce: dependencies.syncLinkedDeviceAuthOnce,
      },
    );
    const result = lifecycle.result;
    print(output, {
      ok: true,
      id: auth.id,
      subject: auth.subject,
      itemsStored: result.itemsStored,
      // Compatibility field for the bundled WhatsApp projection.
      ...(auth.provider === "whatsapp"
        ? { messagesStored: result.itemsStored }
        : {}),
      projection: result.projection,
      presenceMode: "quiet",
      emitsProtocolAcknowledgements: result.emitsProtocolAcknowledgements,
    }, arguments_.json);
    return 0;
  }
  if (arguments_.command === "auth-add") {
    const auth = arguments_.linkedDeviceProvider !== undefined
      ? createAuth(arguments_.id, {
        linkedDeviceProvider: arguments_.linkedDeviceProvider,
        deviceStore: arguments_.deviceStore === undefined
          ? join(
            ghostgetStateHome(environment),
            "linked-device-stores",
            arguments_.id,
          )
          : resolve(arguments_.deviceStore),
        ...(arguments_.subject === undefined ? {} : { subject: arguments_.subject }),
      })
      : arguments_.oauthProvider !== undefined
      ? createAuth(arguments_.id, {
        oauthProvider: arguments_.oauthProvider,
        tokenFile: arguments_.tokenFile ?? "",
        scopes: arguments_.scopes ?? [],
        ...(arguments_.subject === undefined ? {} : { subject: arguments_.subject }),
      })
      : arguments_.browserProfile !== undefined
        ? createAuth(arguments_.id, {
          browserProfile: arguments_.browserProfile,
          ...(arguments_.browserExecutable === undefined
            ? {}
            : { browserExecutable: arguments_.browserExecutable }),
          trustUnfilteredEgress: arguments_.trustProfileEgress,
          ...(arguments_.cookieSource === undefined ? {} : { cookieSource: arguments_.cookieSource }),
          ...(arguments_.cookieProfile === undefined ? {} : { cookieProfile: arguments_.cookieProfile }),
          ...(arguments_.subject === undefined ? {} : { subject: arguments_.subject }),
        })
        : arguments_.cookieSource !== undefined
          ? createAuth(arguments_.id, {
            source: arguments_.cookieSource,
            ...(arguments_.cookieProfile === undefined ? {} : { profile: arguments_.cookieProfile }),
            ...(arguments_.subject === undefined ? {} : { subject: arguments_.subject }),
          })
          : arguments_.cookiesFile !== undefined
            ? createAuth(arguments_.id, {
              cookiesFile: resolve(arguments_.cookiesFile),
              ...(arguments_.subject === undefined ? {} : { subject: arguments_.subject }),
            })
            : (() => { throw new Error("auth add has no selected locator"); })();
    saveAuth(auth, environment, { force: arguments_.force });
    let linkedDeviceNext: string | undefined;
    if (auth.kind === "linked-device-store") {
      const binding = dependencies.providerPluginRegistry.resolveAccountRoute(
        auth.provider,
      );
      linkedDeviceNext = binding?.transport === "linked-device"
        && binding.linkedDeviceLifecycle !== undefined
        ? `ghostget auth pair ${safe(auth.id)} (optionally add --phone <international-number>)`
        : `ghostget auth bind ${safe(auth.id)} --site ${safe(auth.provider)}`;
    }
    const saved = authSavedLines(authSummary(auth), outputStyle(environment, output), linkedDeviceNext);
    // The linked-device hint has always been part of the result; keep it for
    // every audience so scripts that pair next still see it.
    const savedAudience = outputAudience(environment, output);
    writeAuthLines(
      { ...saved, result: savedAudience === "human" || linkedDeviceNext === undefined ? saved.result : `${saved.result}\nNext: ${linkedDeviceNext}` },
      savedAudience,
      output,
    );
    return 0;
  }
  if (arguments_.command === "auth-remove") {
    if (!arguments_.yes) {
      throw new Error(
        "auth remove requires --yes; this removes the locator, any Ghostget-managed OAuth credential, and local caches, but does not revoke browser or provider-side grants",
      );
    }
    const removed = removeAuth(arguments_.id, environment);
    output.stdout(removed ? `Removed auth locator ${safe(arguments_.id)}.\n` : `Auth locator ${safe(arguments_.id)} was not present.\n`);
    return 0;
  }
  if (arguments_.command === "plugin-init") {
    const result = initPortableProviderPlugin({
      id: arguments_.id,
      displayName: arguments_.displayName,
      surfaceId: arguments_.surfaceId,
      origin: arguments_.origin,
      operation: arguments_.operation,
      transport: arguments_.transport,
      ...(arguments_.requiredScopeSets === undefined
        ? {}
        : { requiredScopeSets: arguments_.requiredScopeSets }),
      ...(arguments_.coverage === undefined
        ? {}
        : { coverage: arguments_.coverage }),
      output: resolve(arguments_.output),
    });
    if (arguments_.json) {
      print(output, { ok: true, ...result }, true);
    } else {
      output.stdout(
        `Created inert portable plugin ${safe(result.manifest.id)} at ${safe(result.path)}.\n`,
      );
      output.stdout(
        `Next: ghostget plugin check ${safe(result.path)} && ghostget plugin test ${safe(result.path)}\n`,
      );
    }
    return 0;
  }
  if (arguments_.command === "plugin-scaffold") {
    const outputDirectory = resolve(arguments_.output);
    const files = scaffoldWebProvider({
      site: arguments_.site,
      displayName: arguments_.displayName,
      origin: arguments_.origin,
      operation: arguments_.operation,
      risk: arguments_.risk,
      evidencePath: resolve(arguments_.evidence),
      candidateIndex: arguments_.candidate,
      outputDirectory,
    });
    const pluginId = `${arguments_.site}-web`;
    const result = {
      status: "capture-required",
      executable: false,
      pluginId,
      outputDirectory,
      files: files.map((file) => file.slice(outputDirectory.length + 1)),
      next:
        `Review the source unit at src/plugins/${pluginId}, then run 'ghostget plugin check src/plugins/${pluginId}'; the scaffold performs no request and contains no browser action.`,
    } as const;
    if (arguments_.json) {
      print(output, result, true);
    } else {
      output.stdout(
        `Created network-inert capture-required source plugin ${safe(pluginId)} at ${safe(outputDirectory)}.\n`,
      );
      for (const file of result.files) output.stdout(`- ${safe(file)}\n`);
      output.stdout(`${safe(result.next)}\n`);
    }
    return 0;
  }
  if (arguments_.command === "plugin-check") {
    const directory = resolve(arguments_.path);
    if (
      existsSync(join(directory, PORTABLE_PROVIDER_PLUGIN_MANIFEST_NAME))
      || existsSync(join(directory, WRENCH_PORTABLE_PROVIDER_PLUGIN_MANIFEST_NAME))
      || existsSync(join(directory, LEGACY_PORTABLE_PROVIDER_PLUGIN_MANIFEST_NAME))
    ) {
      const result = checkPortableProviderPlugin(directory);
      if (arguments_.json) {
        print(output, { ok: true, plugin: result }, true);
      } else {
        output.stdout(
          `Checked portable provider plugin ${safe(result.id)} ${safe(result.bundleSha256)} at ${safe(result.path)}.\n`,
        );
        output.stdout(
          `Activation: ${result.activation}; execution requires explicit trust at install.\n`,
        );
      }
      return 0;
    }
    const result = checkSourceProviderPluginDirectory(directory);
    if (arguments_.json) {
      print(output, result, true);
    } else {
      output.stdout(
        `Checked source provider plugin ${safe(result.pluginId)} at ${safe(result.directory)}.\n`,
      );
      output.stdout("State: capture-required; executable: no.\n");
      for (const file of result.files) output.stdout(`- ${safe(file)}\n`);
    }
    return 0;
  }
  if (arguments_.command === "plugin-test") {
    const result = await testPortableProviderPlugin(
      resolve(arguments_.path),
      { trustExecutableCode: arguments_.trustCode },
    );
    print(
      output,
      arguments_.json
        ? result
        : `Portable plugin ${result.pluginId}: ${result.inert} inert reservation(s), ${result.executed} secret-free fixture(s) passed.`,
      arguments_.json,
    );
    return 0;
  }
  if (arguments_.command === "plugin-pack") {
    const result = packPortableProviderPlugin(
      resolve(arguments_.path),
      resolve(arguments_.output),
    );
    print(
      output,
      arguments_.json
        ? { ok: true, ...result }
        : `Packed immutable portable plugin ${result.bundleSha256} at ${result.path}.`,
      arguments_.json,
    );
    return 0;
  }
  if (arguments_.command === "plugin-install") {
    // A settled duplicate successor releases its source's hold on the bundle.
    supersedeSettledDuplicateSources(environment);
    const packagePath = resolve(arguments_.path);
    const checked = checkPortableProviderPlugin(packagePath);
    if (dependencies.providerPluginRegistry.get(checked.id) !== undefined) {
      throw new Error(
        `portable plugin ${checked.id} conflicts with a trusted source plugin ID`,
      );
    }
    const current = showPortableProviderPlugin(checked.id, environment);
    const currentDigest = current?.summary.bundleSha256;
    if (
      arguments_.expectedCurrent !== undefined
      && arguments_.expectedCurrent !== currentDigest
    ) {
      throw new Error(
        `portable plugin ${checked.id} changed from --expected-current`,
      );
    }
    const installed = installPortableProviderPlugin(packagePath, {
      trustExecutableCode: arguments_.trustCode,
      expectedCurrentBundleSha256:
        arguments_.expectedCurrent ?? currentDigest ?? null,
      assertActivatable: (candidate) =>
        assertPortableProviderPluginActivatable(
          candidate,
          dependencies.providerPluginRegistry,
          environment,
        ),
      assertCurrentQuiescent: (bundleSha256, artifactPath) =>
        assertPortableProviderPluginQuiescent(
          bundleSha256,
          artifactPath,
          environment,
        ),
      environment,
    });
    print(
      output,
      arguments_.json
        ? { ok: true, plugin: installed }
        : `Trusted and enabled portable plugin ${installed.id} ${installed.bundleSha256}.`,
      arguments_.json,
    );
    return 0;
  }
  if (arguments_.command === "plugin-doctor") {
    const report = doctorPortableProviderPlugins(environment);
    print(
      output,
      arguments_.json
        ? report
        : report.ok
          ? `Portable plugin store: ${report.installed} installation(s) verified.`
          : `Portable plugin store is invalid: ${report.issues.join("; ")}`,
      arguments_.json,
    );
    return report.ok ? 0 : 3;
  }
  if (
    arguments_.command === "plugin-disable"
    || arguments_.command === "plugin-remove"
  ) {
    if (
      arguments_.command === "plugin-remove"
      && !arguments_.yes
    ) {
      throw new Error(
        "plugin remove requires --yes; activation is removed while immutable trust and artifact evidence are retained",
      );
    }
    // A settled duplicate successor releases its source's hold on the bundle.
    supersedeSettledDuplicateSources(environment);
    const current = showPortableProviderPlugin(arguments_.id, environment);
    if (current === null) {
      throw new Error(`portable plugin ${arguments_.id} is not installed`);
    }
    if (
      arguments_.expectedCurrent !== undefined
      && arguments_.expectedCurrent
        !== current.summary.bundleSha256
    ) {
      throw new Error(
        `portable plugin ${arguments_.id} changed from --expected-current`,
      );
    }
    const expectedBundleSha256 =
      arguments_.expectedCurrent ?? current.summary.bundleSha256;
    const result = arguments_.command === "plugin-disable"
      ? disablePortableProviderPlugin(arguments_.id, {
          expectedBundleSha256,
          assertQuiescent: (bundleSha256, artifactPath) =>
            assertPortableProviderPluginQuiescent(
              bundleSha256,
              artifactPath,
              environment,
            ),
          environment,
        })
      : removePortableProviderPlugin(arguments_.id, {
          expectedBundleSha256,
          assertQuiescent: (bundleSha256, artifactPath) =>
            assertPortableProviderPluginQuiescent(
              bundleSha256,
              artifactPath,
              environment,
            ),
          environment,
        });
    print(
      output,
      arguments_.json
        ? { ok: true, plugin: result }
        : arguments_.command === "plugin-disable"
          ? `Disabled portable plugin ${result.id} ${result.bundleSha256}.`
          : `Removed portable plugin ${result.id} activation; immutable audit bytes were retained.`,
      arguments_.json,
    );
    return 0;
  }
  if (arguments_.command === "adapter-init") {
    const directory = resolve(arguments_.output);
    const path = join(directory, "wrench-adapter.json");
    const manifest = arguments_.target.kind === "origin"
      ? emptyManifest(arguments_.id, arguments_.target.origin)
      : manifestFromPlatform(arguments_.id, arguments_.target.surfaceId);
    if (arguments_.force) writePrivateJson(path, manifest);
    else if (!createPrivateJsonIfAbsent(path, manifest).created) throw new Error(`manifest already exists: ${path}`);
    output.stdout(`Created adapter manifest ${safe(path)}.\n`);
    if (arguments_.target.kind === "platform") {
      output.stdout(`Copied reviewed ${safe(arguments_.target.surfaceId)} origins into an empty, uninstalled manifest; no capability was created.\n`);
      if (socialPlatformCatalog[arguments_.target.surfaceId].originPolicy.additionalExactOrigins.state === "adapter-declared") {
        output.stdout("No custom publication origin was inferred; initialize that exact HTTPS origin with --origin instead.\n");
      }
    }
    return 0;
  }
  if (arguments_.command === "adapter-sync-bundled") {
    const { syncBundledAdapters } = await import(
      "./scripts/sync-bundled-adapters"
    );
    const result = await syncBundledAdapters({
      environment,
      output: arguments_.json
        ? { stdout: () => {}, stderr: output.stderr }
        : output,
    });
    if (arguments_.json) {
      print(output, { ok: true, ...result }, true);
    } else {
      output.stdout(
        `Bundled adapter generation ${safe(result.commitId)} installed ${String(result.installed)} and preserved ${String(result.preserved)}.\n`,
      );
    }
    return 0;
  }
  if (arguments_.command === "adapter-validate") {
    const result = readManifestFile(
      resolve(arguments_.path),
      dependencies.providerPluginRegistry,
    );
    print(output, result.ok
      ? {
          ok: true,
          id: result.value.id,
          version: result.value.version,
          surfaceId: result.value.surfaceId ?? null,
          manifestHash: manifestHash(result.value),
          operations: Object.keys(result.value.operations),
        }
      : { ok: false, issues: result.issues }, arguments_.json);
    return result.ok ? 0 : 2;
  }
  if (arguments_.command === "adapter-install") {
    const installed = withPortableProviderPluginCatalogLock(
      portableProviderPluginStoreRoot(environment),
      new Date(),
      () => {
        const currentRegistry =
          dependencies.createPortableProviderPluginCatalog(
          dependencies.providerPluginRegistry,
          environment,
        ).registry;
        const result = readManifestFile(
          resolve(arguments_.path),
          currentRegistry,
        );
        if (!result.ok) {
          throw new Error(`invalid manifest: ${result.issues.join("; ")}`);
        }
        if (
          currentRegistry.resolveOwnedManifest(
            result.value.id,
          ) !== undefined
        ) {
          throw new Error(
            `adapter ${result.value.id} is owned by an enabled portable provider plugin`,
          );
        }
        if (
          result.value.schemaVersion === 1
          && (
            result.value.id !== "linkedin"
            || !canonicalJsonSha256Matches(
              GHOSTGET_LEGACY_LINKEDIN_MANIFEST_HASH,
              result.value,
            )
          )
        ) {
          throw new Error(
            "schemaVersion 1 installs are restricted to the exact archived LinkedIn v0.4.0 migration fixture",
          );
        }
        let force = arguments_.force;
        let expectedCurrentContentSha256: string | undefined;
        if (arguments_.upgradeFrom !== undefined) {
          const priors = arguments_.upgradeFrom.map((path) => {
            const prior = readDiagnosticManifestFile(
              resolve(path),
              currentRegistry,
            );
            if (!prior.ok) {
              throw new Error(
                `invalid prior bundled manifest: ${prior.issues.join("; ")}`,
              );
            }
            if (prior.value.id !== result.value.id) {
              throw new Error(
                "--upgrade-from manifests must have the same adapter ID",
              );
            }
            return prior.value;
          });
          const priorHashes = new Set(
            priors.map((prior) => manifestHash(prior)),
          );
          if (priorHashes.size !== priors.length) {
            throw new Error(
              "--upgrade-from manifests must identify distinct adapter versions",
            );
          }
          const installedSnapshot =
            loadInstalledDiagnosticManifestSnapshot(
              result.value.id,
              environment,
              currentRegistry,
            );
          const current = installedSnapshot.result;
          force = current.ok
            && priorHashes.has(manifestHash(current.value));
          if (force) {
            if (installedSnapshot.contentSha256 === null) {
              throw new Error(
                "installed adapter snapshot omitted its content hash",
              );
            }
            expectedCurrentContentSha256 =
              installedSnapshot.contentSha256;
          }
          if (
            current.ok
            && !force
            && manifestHash(current.value) !== manifestHash(result.value)
          ) {
            throw new Error(
              `adapter ${result.value.id} differs from the current manifest and all upgrade baselines; preserved the user-modified install`,
            );
          }
        }
        const path = installManifest(result.value, {
          force,
          environment,
          registry: currentRegistry,
          ...(expectedCurrentContentSha256 === undefined
            ? {}
            : { expectedCurrentContentSha256 }),
        });
        return Object.freeze({ id: result.value.id, path });
      },
    );
    writeAuthLines(
      adapterInstalledLines(safe(installed.id), outputStyle(environment, output)),
      outputAudience(environment, output),
      output,
    );
    return 0;
  }
  if (arguments_.command === "adapter-remove") {
    if (!arguments_.yes) {
      throw new Error(
        "adapter remove requires --yes; existing previews for it will fail closed",
      );
    }
    const removed = withPortableProviderPluginCatalogLock(
      portableProviderPluginStoreRoot(environment),
      new Date(),
      () => removeInstalledManifest(arguments_.id, environment),
    );
    output.stdout(removed ? `Removed adapter ${safe(arguments_.id)}.\n` : `Adapter ${safe(arguments_.id)} was not present.\n`);
    return 0;
  }
  if (arguments_.command === "derive-start") {
    const auth = loadAuth(arguments_.authId, environment);
    if (auth.kind === "oauth-token-file") {
      throw new Error(
        `auth locator ${auth.id} is for official ${auth.provider} API capabilities and cannot start an agent-browser derivation; use cookie/profile auth`,
      );
    }
    if (auth.kind === "linked-device-store") {
      throw new Error(
        `auth locator ${auth.id} is a ${auth.provider} linked-device protocol realm and cannot start an agent-browser derivation`,
      );
    }
    const session = await startDerivation(
      arguments_.adapterId,
      arguments_.url,
      auth,
      {
        allowRemoteActions: arguments_.allowRemoteActions,
        contentMode: arguments_.contentMode,
        browserDomains: arguments_.browserDomains,
        cookieOrigins: arguments_.cookieOrigins,
        fixtureSources: arguments_.fixtureSources,
        headed: arguments_.headed,
        environment,
      },
    );
    output.stdout(safeJson({
      ok: true,
      derivationId: session.id,
      targetOrigin: session.targetOrigin,
      allowRemoteActions: session.allowRemoteActions,
      contentMode: session.contentMode,
      fixtures: derivationFixtureSummaries(session.fixtures),
      domainContainment: session.profilePath === null,
      browserDomains: session.browserDomains,
      next: [
        `ghostget derive browser ${session.id} -- snapshot -i`,
        `ghostget derive review ${session.id} --limit 50 --json`,
        `ghostget derive finish ${session.id} --output ./wrench-${session.adapterId}`,
      ],
      warning: session.profilePath === null
        ? "Page loads can cause background writes such as read receipts. Private review seals the recorder; raw HAR data remains task-owned temporary state and is deleted at finish/discard."
        : "This profile-backed browser has unfiltered egress; browserDomains is review metadata, not network containment. Page loads can contact other origins and cause background writes such as read receipts. Private review seals the recorder; raw HAR data remains task-owned temporary state and is deleted at finish/discard.",
    }));
    return 0;
  }
  if (arguments_.command === "derive-list") {
    const values = listDerivations(environment);
    print(output, arguments_.json ? { ok: true, derivations: values } : values, arguments_.json);
    return 0;
  }
  if (arguments_.command === "derive-browser") {
    const result = await runDerivationBrowserCommand(arguments_.id, arguments_.browserArguments, environment);
    print(output, result, arguments_.json);
    return 0;
  }
  if (arguments_.command === "derive-review") {
    let selection: DerivationReviewSelection;
    if (arguments_.selection.kind === "entry") {
      if (arguments_.selection.stdinMode === "fixtures") {
        let value: unknown;
        try {
          value = JSON.parse(await readStdinBounded(64 * 1024)) as unknown;
        } catch {
          throw new Error("derive review fixtures must be valid UTF-8 JSON on stdin");
        }
        const fixtures: DerivationReviewFixtures = parseDerivationReviewFixtures(value);
        selection = {
          kind: "entry",
          entryIndex: arguments_.selection.entryIndex,
          fixtures,
        };
      } else if (arguments_.selection.stdinMode === "field-names") {
        let value: unknown;
        try {
          value = JSON.parse(await readStdinBounded(8 * 1024)) as unknown;
        } catch {
          throw new Error("derive review field names must be valid UTF-8 JSON on stdin");
        }
        const fieldNames: DerivationReviewFieldNames =
          parseDerivationReviewFieldNames(value);
        selection = {
          kind: "entry",
          entryIndex: arguments_.selection.entryIndex,
          fieldNames,
        };
      } else {
        selection = {
          kind: "entry",
          entryIndex: arguments_.selection.entryIndex,
          fixtures: {},
        };
      }
    } else selection = arguments_.selection;
    const result = await reviewDerivation(
      arguments_.id,
      selection,
      environment,
      arguments_.reviewOrigin,
    );
    print(output, { ok: true, sealed: true, ...result }, arguments_.json);
    return 0;
  }
  if (arguments_.command === "derive-finish") {
    const result = await finishDerivation(arguments_.id, arguments_.output, {
      force: arguments_.force,
      registry: dependencies.providerPluginRegistry,
      ...(arguments_.reviewOrigin === undefined ? {} : { reviewOrigin: arguments_.reviewOrigin }),
      ...(arguments_.surfaceId === undefined ? {} : { surfaceId: arguments_.surfaceId }),
      environment,
    });
    print(output, {
      ok: true,
      observedEntries: result.analysis.observedEntries,
      candidates: result.analysis.candidates.length,
      manifestPath: result.manifestPath,
      candidatesPath: result.candidatesPath,
      internalApiCandidates: result.internalEvidence.candidates.length,
      evidencePath: result.evidencePath,
      reservationPath: result.reservationPath,
      rawHarRetained: false,
      next: [
        `Review ${result.reservationPath}`,
        `Edit ${result.manifestPath} only after exact request/response review`,
        `ghostget adapter validate ${result.manifestPath}`,
        `ghostget adapter install ${result.manifestPath}`,
      ],
    }, arguments_.json);
    return 0;
  }
  if (arguments_.command === "derive-discard") {
    if (!arguments_.yes) throw new Error("derive discard requires --yes because it deletes the private session and raw HAR");
    const discarded = await discardDerivation(arguments_.id, environment);
    output.stdout(discarded ? "Discarded the derivation and deleted its private artifacts.\n" : "Derivation was not present.\n");
    return 0;
  }
  if (arguments_.command === "derive-analyze") {
    const analysis = analyzeHarFile(resolve(arguments_.har), arguments_.adapterId, arguments_.origin);
    const result = writeDerivationScaffold(arguments_.output, analysis, {
      force: arguments_.force,
      registry: dependencies.providerPluginRegistry,
      ...(arguments_.surfaceId === undefined ? {} : { surfaceId: arguments_.surfaceId }),
    });
    print(output, { ok: true, observedEntries: analysis.observedEntries, candidates: analysis.candidates.length, ...result }, arguments_.json);
    return 0;
  }
  if (arguments_.command === "omni-read") {
    const request = await readInput(arguments_.inputSource);
    const common = {
      environment,
      registry: dependencies.providerPluginRegistry,
    } as const;
    const value = arguments_.identityOnly
      ? dependencies.identifyOmniView(request, common)
      : arguments_.cacheOnly
        ? dependencies.readCachedOmniViewInternal(request, common)
        : arguments_.fromExactCache
          ? dependencies.rebuildOmniViewFromExactCache(request, common)
          : await dependencies.revalidateOmniViewInternal(request, {
              ...common,
              headed: arguments_.headed,
              ...(signal === undefined ? {} : { signal }),
            });
    if (arguments_.json) output.stdout(exactTerminalJson(value));
    else print(output, value, false);
    if (value.view?.sources.some((source) => source.coverage.state === "observed")) onUsefulResult?.();
    return 0;
  }
  if (arguments_.command === "invoke") {
    if (arguments_.duplicateRiskOf.length > 0 && !arguments_.preview) {
      throw new Error("--duplicate-risk-of requires an explicit --preview");
    }
    // A cache-only invocation is a read path: it binds the account's current
    // auth incarnation and never creates one. `--projection-identity-only` is
    // the SDK's identity preflight for a live invoke, so it is execution
    // preparation and may create a missing incarnation (D14).
    const invocation = (arguments_.cacheOnly ? prepareReadInvocation : prepareInvocation)(
      arguments_.adapterId,
      arguments_.operationId,
      await readInput(arguments_.inputSource),
      arguments_.authId,
      environment,
      dependencies.providerPluginRegistry,
    );
    const operation = invocation.manifest.operations[arguments_.operationId];
    if (operation === undefined) throw new Error("operation disappeared before invocation");
    if (operation.risk === "R4") {
      throw new Error("R4 capabilities are blocked by wrench");
    }
    if (arguments_.cacheOnly && operation.risk !== "R1") {
      throw new Error("invoke --cache-only is available only for R1 capabilities");
    }
    if (arguments_.projectionIdentityOnly && operation.risk !== "R1") {
      throw new Error("invoke --projection-identity-only is available only for R1 capabilities");
    }
    if (operation.risk === "R1") {
      if (arguments_.duplicateRiskOf.length > 0) {
        throw new Error(
          "--duplicate-risk-of is available only for one-dispatch R3 web-session or portable-plugin posts.publish mutations",
        );
      }
      if (arguments_.projectionIdentityOnly) {
        const inputHash = sha256(canonicalJson(invocation.input));
        const authIdentity = invocation.readProjectionAuthIdentityHash;
        if (
          authIdentity === undefined
          || !/^[a-f0-9]{64}$/u.test(authIdentity)
        ) {
          throw new Error(
            "prepared invocation is missing its auth lifetime identity; prepare it again",
          );
        }
        const authHash = sha256(canonicalJson(invocation.auth));
        if (invocation.auth.subject === undefined) {
          const view = {
            ok: true,
            source: "projection-identity",
            status: "unbound",
            authIdentity,
            authHash,
            inputHash,
          };
          if (arguments_.json) output.stdout(exactTerminalJson(view));
          else print(output, view, false);
          return 0;
        }
        const query = createReadProjectionQueryForInvocation(
          invocation,
          environment,
          dependencies.providerPluginRegistry,
        );
        const view = {
          ok: true,
          source: "projection-identity",
          status: "ready",
          authIdentity,
          authHash,
          inputHash,
          projection: { key: query.key },
        };
        if (arguments_.json) output.stdout(exactTerminalJson(view));
        else print(output, view, false);
        return 0;
      }
      if (arguments_.preview) {
        printPreview(output, directPreviewView(invocation), arguments_.json);
        return 0;
      }
      if (arguments_.cacheOnly) {
        const result = dependencies.readCachedPreparedCapability(invocation, {
          environment,
          registry: dependencies.providerPluginRegistry,
        });
        const view = cachedInvocationView(result);
        if (arguments_.json) output.stdout(exactTerminalJson(view));
        else print(output, view, false);
        if (result.status === "hit") onUsefulResult?.();
        return result.status === "hit" ? 0 : 3;
      }
      const result = await dependencies.revalidatePreparedCapability(
        invocation,
        {
          headed: arguments_.headed,
          environment,
          registry: dependencies.providerPluginRegistry,
          ...(signal === undefined ? {} : { signal }),
        },
      );
      const view = revalidatedInvocationView(result);
      if (arguments_.json) output.stdout(exactTerminalJson(view));
      else print(output, view, false);
      if (result.live.receipt.status === "failed" && result.live.readFailure?.category === "contract-drift"
        && result.live.receipt.risk === "R1" && result.live.output === null
        && result.live.receipt.dispatchStarted === false && result.live.receipt.dispatch.planned === 0
        && result.live.receipt.dispatch.started === 0 && result.live.receipt.dispatch.verified === 0
        && result.live.receipt.adapter.id === invocation.manifest.id && result.live.receipt.operation === invocation.operationId
        && !result.live.replayed && result.live.privateArtifactsPreserved !== true && signal?.aborted !== true) {
        reportContractRepairLead(() => projectContractRepairSignal(invocation.manifest, invocation.operationId, "contract-drift", dependencies.providerPluginRegistry), environment, output, arguments_.json);
      }
      if (result.live.receipt.status === "succeeded" || result.live.receipt.status === "submitted") onUsefulResult?.();
      return result.live.receipt.status === "succeeded" || result.live.receipt.status === "submitted" ? 0 : result.live.receipt.status === "indeterminate" ? 5 : 3;
    }
    const stored = createAndSaveInvocationPlan(
      invocation,
      environment,
      new Date(),
      dependencies.providerPluginRegistry,
      { duplicateRiskOf: arguments_.duplicateRiskOf },
    );
    printPreview(
      output,
      previewView(stored, invocation, arguments_.headed),
      arguments_.json,
    );
    return arguments_.preview ? 0 : 4;
  }
  if (arguments_.command === "confirm") {
    const selectedPlan = loadInvocationPlan(arguments_.digest, environment);
    if (selectedPlan.plan.messagingComposite !== undefined) {
      if (
        selectedPlan.plan.messagingComposite.contextBindingSha256 === null
        || selectedPlan.plan.messagingComposite.sourceConversationCoordinateSha256
          === null
      ) throw new Error(
        "predecessor messaging plan lacks current context evidence; preview the action again",
      );
      if (
        arguments_.privateOutput === undefined
        || arguments_.receiptBindingOutput === undefined
      ) throw new Error(
        "messaging confirmation requires --private-output and --receipt-binding-output",
      );
      loadMessagingPreviewForConfirmationInternal(arguments_.digest, { environment });
      const privateOutput = validateMessagingPrivateOutputPath(
        arguments_.privateOutput,
        environment,
      );
      const receiptBindingOutput = validateMessagingPrivateOutputPath(
        arguments_.receiptBindingOutput,
        environment,
      );
      if (privateOutput === receiptBindingOutput) {
        throw new Error(
          "messaging confirmation requires distinct private output and receipt-binding paths",
        );
      }
      const reservations = reserveMessagingPrivateOutputPair(
        privateOutput,
        receiptBindingOutput,
        environment,
      );
      const result = await confirmMessagingInvocation(arguments_.digest, {
        environment,
        registry: dependencies.providerPluginRegistry,
        ...(signal === undefined ? {} : { signal }),
      });
      // Once dispatch settles, publish its body-free recovery handle before
      // either reserved private export can fail.
      output.stdout(exactTerminalJson(result.receipt));
      writeReservedMessagingPrivateOutput(
        reservations.run,
        result.run,
        environment,
      );
      writeReservedMessagingPrivateOutput(
        reservations.receiptBinding,
        result.receiptBinding,
        environment,
      );
      if (result.receipt.state === "submitted") onUsefulResult?.();
      return result.receipt.state === "submitted"
        ? 0
        : result.receipt.state === "indeterminate"
          ? 5
          : 3;
    }
    if (
      arguments_.privateOutput !== undefined
      || arguments_.receiptBindingOutput !== undefined
    ) throw new Error("messaging output options require a messaging composite plan");
    const result = await confirmInvocation(arguments_.digest, {
      headed: arguments_.headed,
      environment,
      registry: dependencies.providerPluginRegistry,
      ...(signal === undefined ? {} : { signal }),
    });
    print(output, invocationView(result), arguments_.json);
    if (result.receipt.status === "succeeded" || result.receipt.status === "submitted") onUsefulResult?.();
    return result.receipt.status === "succeeded" || result.receipt.status === "submitted" ? 0 : result.receipt.status === "indeterminate" ? 5 : 3;
  }
  if (arguments_.command === "runs-list") {
    repairInterruptedConfirmationClaims(environment);
    repairInterruptedRunJournals(environment);
    const receipts = listRunReceipts(environment);
    print(output, arguments_.json ? { ok: true, runs: receipts } : receipts, arguments_.json);
    return 0;
  }
  if (arguments_.command === "runs-reconcile") {
    const linkedDeviceJournal = readLinkedDeviceLifecycleJournal(
      arguments_.runId,
      environment,
    );
    if (linkedDeviceJournal !== null) {
      if (arguments_.inputSource === undefined) {
        throw new Error(
          "linked-device lifecycle reconciliation requires --input with an explicit observed outcome and evidence hash",
        );
      }
      const result = await dependencies
        .reconcileLinkedDeviceLifecycleJournal(
          arguments_.runId,
          await readInput(arguments_.inputSource),
          {
            environment,
            registry: dependencies.providerPluginRegistry,
          },
        );
      print(output, result, arguments_.json);
      return 0;
    }
    const claimRecovery = repairInterruptedConfirmationClaims(environment);
    const runRecovery = repairInterruptedRunJournals(environment);
    if (claimRecovery.invalid > 0 || runRecovery.issues.length > 0) {
      throw new Error(
        "local execution recovery has unresolved state; run ghostget doctor before reconciliation",
      );
    }
    let receipt: ReturnType<typeof readRunReceipt> | null = null;
    try {
      receipt = readRunReceipt(arguments_.runId, environment);
    } catch {
      // The transport-specific reconciler remains responsible for reporting
      // missing, malformed, or legacy receipts. This probe only routes exact
      // schema-6 receipts to the portable evidence path.
    }
    if (
      receipt?.schemaVersion === 6
      && receipt.transport === "portable-provider-plugin"
    ) {
      if (arguments_.inputSource === undefined) {
        const readback = dependencies.portableProviderPluginReadback;
        // An undeclared plugin keeps today's explicit-input path exactly.
        if (
          readback === undefined
          || !readback.declares(receipt.portablePluginContract)
        ) {
          throw new Error(
            "portable plugin reconciliation requires --input with an explicit observed outcome and evidence hash",
          );
        }
        // Without --input, Ghostget itself runs the write's declared
        // readback, bound to this run, its intent, and its auth realm.
        const observed = await reconcilePortableProviderPluginRunFromReadback(
          arguments_.runId,
          {
            registry: dependencies.providerPluginRegistry,
            readback,
            environment,
            ...(signal === undefined ? {} : { signal }),
          },
        );
        print(output, observed, arguments_.json);
        return observed.ok ? 0 : 5;
      }
      const result = dependencies.reconcilePortableProviderPluginRun(
        arguments_.runId,
        await readInput(arguments_.inputSource),
        {
          environment,
          registry: dependencies.providerPluginRegistry,
        },
      );
      print(output, result, arguments_.json);
      // A recorded not-applied claim leaves the run fenced and unsettled.
      return result.ok ? 0 : 5;
    }
    const result = await dependencies.reconcileWebSessionRun(
      arguments_.runId,
      arguments_.inputSource === undefined
        ? undefined
        : await readInput(arguments_.inputSource),
      {
        environment,
        registry: dependencies.providerPluginRegistry,
      },
    );
    print(output, result, arguments_.json);
    return result.ok ? 0 : 5;
  }
  if (arguments_.command === "plans-list") {
    const plans = listInvocationPlans(environment);
    print(output, arguments_.json ? { ok: true, plans } : plans, arguments_.json);
    return 0;
  }
  if (arguments_.command === "plans-cancel") {
    if (!arguments_.yes) throw new Error("plans cancel requires --yes; cancellation permanently removes that encrypted preview");
    const removed = cancelInvocationPlan(arguments_.digest, environment);
    output.stdout(removed ? `Cancelled preview ${safe(arguments_.digest)}.\n` : `Preview ${safe(arguments_.digest)} was not present.\n`);
    return 0;
  }
  if (arguments_.command === "runs-show") {
    const messaging = readMessagingRunIfPresent(arguments_.runId, environment);
    if (messaging !== null) {
      if (
        arguments_.privateOutput === undefined
        || arguments_.receiptBindingOutput === undefined
      ) throw new Error(
        "messaging runs show requires --private-output and --receipt-binding-output",
      );
      const privateOutput = validateMessagingPrivateOutputPath(
        arguments_.privateOutput,
        environment,
      );
      const receiptBindingOutput = validateMessagingPrivateOutputPath(
        arguments_.receiptBindingOutput,
        environment,
      );
      if (privateOutput === receiptBindingOutput) {
        throw new Error(
          "messaging runs show requires distinct private output and receipt-binding paths",
        );
      }
      const result = showMessagingRunInternal(arguments_.runId, { environment });
      writeMessagingPrivateOutput(privateOutput, result.run, environment);
      writeMessagingPrivateOutput(
        receiptBindingOutput,
        result.receiptBinding,
        environment,
      );
      output.stdout(exactTerminalJson(result.receipt));
      return result.receipt.state === "indeterminate" ? 5 : result.receipt.state === "submitted" ? 0 : 3;
    }
    if (
      arguments_.privateOutput !== undefined
      || arguments_.receiptBindingOutput !== undefined
    ) throw new Error("messaging output options require a messaging run");
  }
  repairInterruptedConfirmationClaims(environment);
  repairInterruptedRunJournals(environment);
  const receipt = readRunReceipt(arguments_.runId, environment);
  print(output, receipt, arguments_.json);
  return 0;
}

export async function main(
  rawArguments: readonly string[] = process.argv.slice(2),
  environment: Readonly<Record<string, string | undefined>> = process.env,
  output: Output = defaultOutput,
  dependencyOverrides: Partial<GhostgetDependencies> = {},
  signal?: AbortSignal,
  onUsefulResult?: () => void,
): Promise<number> {
  const parsed = parseGhostgetArguments(rawArguments);
  const stderrIsTTY = output === defaultOutput && process.stderr.isTTY === true;
  if (!parsed.ok) {
    if (wantsJsonErrors(rawArguments, environment, stderrIsTTY)) {
      const parts = ghostgetUsageErrorParts(parsed.message, rawArguments);
      output.stdout(ghostgetErrorJson("usage", parts.message, parts.next));
    } else {
      output.stderr(renderGhostgetUsageError(parsed.message, rawArguments, environment));
    }
    return 2;
  }
  try {
    const { assertGatewayCommandAllowed } = await import("./control/web-policy");
    assertGatewayCommandAllowed(rawArguments, environment);
    let dependencies = resolveDependencies(dependencyOverrides);
    if (
      dependencyOverrides.providerPluginRegistry === undefined
      && commandUsesPortableProviderCatalog(parsed.value.command)
    ) {
      const catalog = dependencies.createPortableProviderPluginCatalog(
        dependencies.providerPluginRegistry,
        environment,
      );
      dependencies = {
        ...dependencies,
        providerPluginRegistry: catalog.registry,
        portableProviderPluginReadback: catalog.readback,
      };
    }
    let usefulResult = false;
    if (output === defaultOutput) {
      configureCookieAccessNotice({
        environment,
        stdinIsTTY: process.stdin.isTTY === true,
        stderrIsTTY: process.stderr.isTTY === true,
        write: (text) => output.stderr(text),
        readKey: (timeoutSeconds) => terminalReadKey(timeoutSeconds),
        confirm: parsed.value.command === "auth-bind",
        record: stateKeychainNoticeRecord(environment),
      });
    }
    const code = await runCommand(
      parsed.value,
      environment,
      output,
      dependencies,
      signal,
      () => { usefulResult = true; },
    ).finally(() => configureCookieAccessNotice(null));
    if (code === 0 && usefulResult && signal?.aborted !== true) {
      try { void Promise.resolve(onUsefulResult?.()).catch(() => undefined); } catch { /* Optional observation cannot alter completed work. */ }
    }
    return code;
  } catch (error) {
    const permissionFailure = renderCookieAccessFailure(error, parsed.value, environment, output);
    if (permissionFailure !== null) return permissionFailure;
    let repairLeadId: string | null = null;
    if (error instanceof ContractCaptureRequiredError && parsed.value.command === "invoke"
      && !parsed.value.cacheOnly && !parsed.value.projectionIdentityOnly && signal?.aborted !== true) {
      repairLeadId = reportContractRepairLead(() => error.signal, environment, output, wantsJsonErrors(rawArguments, environment, stderrIsTTY));
    }
    if (error instanceof LinkedDeviceLifecycleIndeterminateError) {
      const failure = {
        ok: false,
        status: "indeterminate",
        journalId: error.journalId,
      };
      if ("json" in parsed.value && parsed.value.json === true) {
        output.stdout(safeJson(failure));
      } else {
        output.stderr(`ghostget: ${safe(error.message)}\n`);
      }
      return 5;
    }
    if (error instanceof PreservedBrowserArtifactsError) {
      const recoveryHandle = boundedCliRecoveryHandle(error.recoveryHandle);
      const failure = {
        ok: false,
        status: "indeterminate",
        privateArtifactsPreserved: true,
        error: safe(error.message),
        ...(recoveryHandle === null ? {} : { recoveryHandle }),
      };
      if ("json" in parsed.value && parsed.value.json === true) {
        // The recovery handle is an owned, bounded terminal-safe locator.
        // Generic redaction treats its `session=` field as a credential and
        // would destroy the only actionable cleanup handle.
        output.stdout(exactTerminalJson(failure));
      } else {
        output.stderr(
          `ghostget: ${failure.error}${recoveryHandle === null
            ? "; recovery handle was unavailable; run ghostget doctor before retrying"
            : `; recovery handle: ${recoveryHandle}`}\n`,
        );
      }
      return 5;
    }
    const message = safe(error instanceof Error ? error.message : String(error));
    if (wantsJsonErrors(rawArguments, environment, stderrIsTTY)) {
      output.stdout(ghostgetErrorJson("failed", cliSentence(message),
        repairLeadId === null ? "ghostget doctor" : `ghostget contracts repair --id ${repairLeadId} --json`));
    } else {
      output.stderr(`ghostget: ${message}\n`);
    }
    return 3;
  }
}

function commandUsesPortableProviderCatalog(
  command: GhostgetArguments["command"],
): boolean {
  return command === "doctor"
    || command === "capabilities"
    || command === "contracts-catalog"
    || command === "contracts-check"
    || command === "contracts-repair"
    || command === "adapter-validate"
    || command === "derive-analyze"
    || command === "derive-finish"
    || command === "thread-publish"
    || command === "auth-bind"
    || command === "auth-pair"
    || command === "auth-sync"
    || command === "omni-read"
    || command === "messaging-routes"
    || command === "messaging-resolve"
    || command === "messaging-context"
    || command === "messaging-preview"
    || command === "invoke"
    || command === "confirm"
    || command === "runs-reconcile";
}

const GHOSTGET_PROCESS_CLEANUP_PERSISTENCE_MARGIN_MS = 5_000;
const GHOSTGET_PROCESS_GRACEFUL_TERMINATION_TIMEOUT_MS =
  WEB_SESSION_CLEANUP_JOIN_TIMEOUT_MS
  + GHOSTGET_PROCESS_CLEANUP_PERSISTENCE_MARGIN_MS;

type GhostgetProcessBoundaryDependencies = {
  readonly rawArguments: readonly string[];
  readonly environment: Readonly<Record<string, string | undefined>>;
  readonly output: Output;
  readonly runMain: typeof main;
  readonly subscribeTermination: (
    terminate: (signal: NodeJS.Signals) => void,
  ) => () => void;
  readonly scheduleForcedTermination: (
    callback: () => void,
    delayMs: number,
  ) => () => void;
  readonly resendSignal: (signal: NodeJS.Signals) => void;
  readonly setExitCode: (code: number) => void;
  readonly onUsefulResult?: () => void;
};

function subscribeProcessTermination(
  terminate: (signal: NodeJS.Signals) => void,
): () => void {
  const onInterrupt = (): void => terminate("SIGINT");
  const onTerminate = (): void => terminate("SIGTERM");
  process.once("SIGINT", onInterrupt);
  process.once("SIGTERM", onTerminate);
  let subscribed = true;
  return () => {
    if (!subscribed) return;
    subscribed = false;
    process.removeListener("SIGINT", onInterrupt);
    process.removeListener("SIGTERM", onTerminate);
  };
}

function scheduleForcedTermination(
  callback: () => void,
  delayMs: number,
): () => void {
  const timer = setTimeout(callback, delayMs);
  timer.unref();
  return () => clearTimeout(timer);
}

export async function runGhostgetProcess(
  overrides: Partial<GhostgetProcessBoundaryDependencies> = {},
): Promise<void> {
  const dependencies: GhostgetProcessBoundaryDependencies = {
    ...(overrides.onUsefulResult === undefined ? {} : { onUsefulResult: overrides.onUsefulResult }),
    rawArguments: overrides.rawArguments ?? process.argv.slice(2),
    environment: overrides.environment ?? process.env,
    output: overrides.output ?? defaultOutput,
    runMain: overrides.runMain ?? main,
    subscribeTermination:
      overrides.subscribeTermination ?? subscribeProcessTermination,
    scheduleForcedTermination:
      overrides.scheduleForcedTermination ?? scheduleForcedTermination,
    resendSignal:
      overrides.resendSignal ?? ((signal) => process.kill(process.pid, signal)),
    setExitCode:
      overrides.setExitCode ?? ((code) => {
        process.exitCode = code;
      }),
  };
  const controller = new AbortController();
  const terminationState: {
    cancelFallback: (() => void) | null;
  } = { cancelFallback: null };
  let unsubscribeTermination = (): void => undefined;
  let terminating = false;
  const terminate = (signal: NodeJS.Signals): void => {
    if (terminating) return;
    terminating = true;
    controller.abort();
    unsubscribeTermination();
    // Not every upstream browser/capture primitive accepts AbortSignal yet.
    // Leave a hard upper bound, but reserve enough time for the browser's
    // bounded TERM/KILL/stream, close, proxy, and recovery-handle joins. A
    // second OS signal uses its restored default disposition immediately.
    terminationState.cancelFallback = dependencies.scheduleForcedTermination(
      () => dependencies.resendSignal(signal),
      GHOSTGET_PROCESS_GRACEFUL_TERMINATION_TIMEOUT_MS,
    );
  };
  unsubscribeTermination = dependencies.subscribeTermination(terminate);
  let usefulResult = false;
  let code: number | undefined;
  try {
    code = await dependencies.runMain(
      dependencies.rawArguments,
      dependencies.environment,
      dependencies.output,
      {},
      controller.signal,
      () => { usefulResult = true; },
    );
    dependencies.setExitCode(code);
  } finally {
    terminationState.cancelFallback?.();
    unsubscribeTermination();
  }
  if (code === 0 && usefulResult && !controller.signal.aborted) {
    try { void Promise.resolve(dependencies.onUsefulResult?.()).catch(() => undefined); } catch { /* Keep the completed command outcome. */ }
  }
}

if (import.meta.main) {
  await runGhostgetProcess();
}
